#!/usr/bin/env bash
# MacBookPro14,2 / apple-ib-drv/0.1: T1 usb_control_msg() success return fix.
# Experimental: patch for testing on the specific MacBookPro14,2 setup.
# Does not change ACPI, USB bindings, Wi-Fi, NVMe, audio, or sleep hooks.
# Usage: sudo bash MBP14_2-T1-USB-RETURN-FIX.sh --check|--apply|--rollback
set -Eeuo pipefail
umask 077

SRC=/usr/src/apple-ib-drv-0.1/apple-touchbar.c
BACKUP_DIR=/var/backups/mbp14-2-t1-usb-return-fix
BACKUP="$BACKUP_DIR/apple-touchbar.c.before-fix"
KERNEL="$(uname -r)"
MARKER=MBP14_2_T1_USB_RC_NORMALIZATION

say() { printf '[T1 USB fix] %s\n' "$*"; }
die() { printf '[T1 USB fix] ERROR: %s\n' "$*" >&2; exit 1; }
usage() {
  cat <<'USAGE'
Usage:
  sudo bash MBP14_2-T1-USB-RETURN-FIX.sh --check    # read-only preflight
  sudo bash MBP14_2-T1-USB-RETURN-FIX.sh --apply    # back up, patch, DKMS build/install for running kernel
  sudo bash MBP14_2-T1-USB-RETURN-FIX.sh --rollback # restore source and rebuild/install previous DKMS version

Reboot normally after --apply/--rollback; never unload the live T1 driver.
A successful DKMS build is NOT proof that the Touch Bar works after S3.
USAGE
}
[[ $# -eq 1 ]] || { usage; exit 2; }
case $1 in --check|--apply|--rollback) MODE="$1";; --help|-h) usage; exit 0;; *) usage; exit 2;; esac
[[ "$(cat /sys/class/dmi/id/product_name 2>/dev/null || true)" == 'MacBookPro14,2' ]] || die 'This script targets only MacBookPro14,2.'
[[ -f "$SRC" && ! -L "$SRC" ]] || die "Source file not found or symlink: $SRC"
for cmd in python3 dkms cp depmod; do command -v "$cmd" >/dev/null || die "Missing $cmd"; done
[[ -d "/lib/modules/$KERNEL/build" || -d "/usr/lib/modules/$KERNEL/build" ]] || die "Kernel headers missing for $KERNEL"
if [[ $MODE == --check ]]; then
  say "Model: MacBookPro14,2, kernel: $KERNEL"
  say "Source: $SRC"
  if grep -Fq "$MARKER" "$SRC"; then say 'Source: patched'; else say 'Source: not patched'; fi
  if [[ -f "$BACKUP" ]]; then say "Backup: $BACKUP"; else say 'Backup: absent'; fi
  dkms status -m apple-ib-drv || true
  exit 0
fi
(( EUID == 0 )) || die 'Run with sudo.'
[[ -e "/sys/module/apple_ibridge/parameters/skip_acpi_power" ]] || say 'Note: T1 protection parameter not visible. No parameter will be changed.'

patch_source() {
python3 - "$SRC" "$MARKER" <<'PY'
import re
import sys
from pathlib import Path
path = Path(sys.argv[1])
marker = sys.argv[2]
src = path.read_text()
if marker in src:
    print('[T1 USB fix] Already patched; no source change.')
    sys.exit(0)
start = src.find('static int appletb_set_tb_mode(')
end = src.find('static int appletb_set_tb_disp(', start + 1)
if start < 0 or end < 0:
    raise SystemExit('Unexpected function layout: refusing to patch')
part = src[start:end]
if 'usb_control_msg(' not in part or 'if (rc != -EPIPE)' not in part:
    raise SystemExit('Unexpected T1 USB send code: refusing to patch')
if 'if (rc1 == 0)' not in src or 'tb_dev->cur_tb_mode = pending_mode' not in src:
    raise SystemExit('Expected worker success convention absent: refusing to patch')
pattern = re.compile(r'(?m)^([ \t]*)\} while \(\+\+tries < 5\);[ \t]*$')
matches = list(pattern.finditer(part))
if len(matches) != 1:
    raise SystemExit(f'Expected exactly one retry loop, found {len(matches)}; refusing to patch')
match = matches[0]
indent = match.group(1)
addition = (f'\n{indent}/* {marker}: USB reports bytes; worker expects 0. */'
            f'\n{indent}if (rc == 1)'
            f'\n{indent}\trc = 0;'
            f'\n{indent}else if (rc >= 0)'
            f'\n{indent}\trc = -EIO;')
patched = part[:match.end()] + addition + part[match.end():]
path.write_text(src[:start] + patched + src[end:])
print('[T1 USB fix] Patched exactly one T1 USB return-value site.')
PY
}

build_install() {
  say "Building apple-ib-drv/0.1 for $KERNEL (no live module reload)..."
  dkms build -m apple-ib-drv -v 0.1 -k "$KERNEL" --force || return 1
  say 'Installing next-boot DKMS module...'
  dkms install -m apple-ib-drv -v 0.1 -k "$KERNEL" --force || return 1
  depmod -a "$KERNEL" || return 1
}

if [[ $MODE == --apply ]]; then
  if grep -Fq "$MARKER" "$SRC"; then
    say 'Patch already present. No DKMS rebuild performed.'
    exit 0
  fi
  [[ ! -e "$BACKUP" ]] || die "Existing backup found at $BACKUP; refusing to overwrite it."
  mkdir -p -m 0700 "$BACKUP_DIR"
  cp -a -- "$SRC" "$BACKUP"
  say "Backup saved: $BACKUP"
  patch_source
  if ! build_install; then
    say 'Build/install failed. Restoring SOURCE from backup; review DKMS status before reboot.'
    cp -a -- "$BACKUP" "$SRC"
    die 'Patch did not complete. Existing installed module may need dkms reinstall after fixing error.'
  fi
  say 'Done. REBOOT normally; test F-keys, volume, brightness after boot and after S3.'
  say "Rollback: sudo bash $(basename "$0") --rollback"
else
  [[ -f "$BACKUP" ]] || die "No saved source at $BACKUP"
  if ! grep -Fq "$MARKER" "$SRC"; then die 'Patch marker absent; refusing rollback over unrelated edits'; fi
  cp -a -- "$BACKUP" "$SRC"
  if ! build_install; then die 'Rollback build/install failed; source restored; inspect DKMS before reboot'; fi
  say 'Rollback installed for next boot. Reboot normally.'
fi
