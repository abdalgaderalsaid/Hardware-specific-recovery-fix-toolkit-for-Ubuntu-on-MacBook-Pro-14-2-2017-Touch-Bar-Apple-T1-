# Changelog

## 5.2-testing — 2026-10-24 (T1 key input fixed on one tested MacBook)

- **Owner-tested success:** After deep S3, Touch Bar would illuminate after opt-in `ASOC.SOCW(1)`, but emitted `KEY_UNKNOWN` for all keys. Owner subsequently reported the controls working after applying the T1 USB return-code patch and rebooting.
- **Root cause addressed:** T1 `usb_control_msg()` returns **1 byte** when a mode command succeeds; the worker requires `rc1 == 0` to commit `cur_tb_mode`, otherwise its `OFF` state suppresses keys. Normalize `1 -> 0` and unexpected nonnegative return -> `-EIO`, inside T1 path only.
- Integrated this third T1 correction into `MBP14_2-FIX-v5.sh` with guarded code matching, per-run source backup, idempotent application and DKMS build for the current kernel only when the source is changed.
- Included the tested standalone `MBP14_2-T1-USB-RETURN-FIX.sh` for narrow diagnosis and optional rollback.
- Updated read-only `--report`, English/Arabic READMEs, technical notes, troubleshooting and synthetic patch tests.
- **Not yet validated:** installing the combined v5.2 bundle on clean hardware, multi-day resume reliability, other models or kernels; optional `SOCW(1)` remains hazardous.

## 5.1-testing — 2026-10-24 (regression discovered before publication)

- **Known blocker:** Deep S3 resume + 5-second T1 ACPI wake restores the OLED **backlight/display**, but touch controls for sound, brightness, and Fn have **no effect**. Working after cold boot.
- **Withdraw earlier conclusion** that full Touch Bar input returned after S3; user tested buttons only later. Release is **experimental / NOT stable**.
- Added safe, optional `evtest` diagnostics and clarified display-vs-input success criteria.

## 5.1 — 2026-10-24 (updated original v5)

- Retained original file name `MBP14_2-FIX-v5.sh` and archived its prior content under `legacy/`.
- Added safe default `--report`, explicit `--install`, model guard, config backups, no auto reboot, and checks to preserve working sources.
- Preserved BCM43602 board NVRAM/MAC, verified new downloads by Git blob, installed conditional cold-boot PCI recovery (10s timer, 1s accuracy).
- Added `nvme-d3cold.service` protection for `0000:01:00.0` and persistent deep S3 configuration.
- Integrated the narrowly scoped pinned CS8409 PR #220 audio installer helper and safe skip for unrecognized or already patched source.
- Replaced legacy Touch Bar install approach with `apple-ib-drv/0.1`, `apple_touchbar`, protected `skip_acpi_power=1`, explicit `.resume` callback and T1-aware interface readiness test.
- Corrected Apple T1 udev rule to `ENV{DEVTYPE}=="usb_device"`.
- Rejected automatic driver `unbind/bind`; disabled old `apple-ib-tb` binding path and executable backup hooks.
- Added explicitly opt-in, single-call, 5-second-delayed `ASOC.SOCW(1)` wake service and a simple disable path. **Potential hard-freeze risk**.
- Added documentation in English/Arabic, root-cause technical notes, publishing instructions, rollback guidance, and non-invasive packaging tests.

### Validation

Static checks passed; final integrated installer has **not** been executed end-to-end on Mac hardware by the package author. Hardware behaviors were established in iterative tests on one owner's MacBookPro14,2. Upstream T1 fresh-install source is not yet SHA-pinned.
