#!/usr/bin/env bash
# =============================================================================
#  MBP14_2-FIX-v5.sh - Ubuntu 26.04 on MacBookPro14,2 (2017 13" Touch Bar, A1706)
#
#  Built from:
#    - r/linux_on_mac: "MacBook Pro 2017 (MacBookPro14,2) on Ubuntu 26.04"
#    - github.com/vfontanela/macbookpro14-linux-support  (Wi-Fi NVRAM, T1 Touch Bar)
#    - github.com/davidjo/snd_hda_macbookpro             (CS8409 audio, commit cb27cc4)
#
#  Rules built in:
#    - macaddr in the Wi-Fi NVRAM always comes from `ethtool -P` and is never removed
#    - if the Wi-Fi interface exists and its NVRAM already has that MAC, the NVRAM is kept
#      (--force-nvram replaces it)
#    - every file that is replaced is first copied to /var/backups/mbp14-2-fix-v5-<time>/
#    - another Touch Bar DKMS module is removed only after you confirm
#    - audio is never tested through hw:0,0 (that device has no volume control)
# =============================================================================
set -u

# ---------- fixed settings ----------
SRC_DIR="/usr/local/src/mbp14-2"
VENDOR_DIR="$SRC_DIR/macbookpro14-linux-support"
CIRRUS_DIR="$SRC_DIR/snd_hda_macbookpro"
VENDOR_URL="https://github.com/vfontanela/macbookpro14-linux-support.git"
CIRRUS_URL="https://github.com/davidjo/snd_hda_macbookpro.git"
CIRRUS_PIN="cb27cc483f4fe98be03a4f4bef466c00aa7d244b"

FW_DIR="/usr/lib/firmware/brcm"
BOARD_FW="$FW_DIR/brcmfmac43602-pcie.Apple Inc.-MacBookPro14,2.txt"
GENERIC_FW="$FW_DIR/brcmfmac43602-pcie.txt"
PACKAGED_BIN="$FW_DIR/brcmfmac43602-pcie.bin"
MODPROBE_DIR="/etc/modprobe.d"
REGDOM_CONF="$MODPROBE_DIR/10-wifi-regdom.conf"
NM_CONF="/etc/NetworkManager/conf.d/10-mbp2017-wifi.conf"
TB_CONF="$MODPROBE_DIR/mbp-t1-touchbar.conf"
TB_OPTS="options apple_ib_tb fnmode=2 idle_timeout=-1 dim_timeout=-1"

KVER="$(uname -r)"                 # e.g. 7.0.0-38-generic
KBASE="${KVER%%-*}"                # e.g. 7.0.0
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP_DIR="/var/backups/mbp14-2-fix-v5-$STAMP"
LOG="/var/log/mbp14-2-fix-v5.log"

usage() {
  cat <<'EOF'
Usage:
  sudo bash MBP14_2-FIX-v5.sh SA                 set up everything (SA = your Wi-Fi country code)
  sudo bash MBP14_2-FIX-v5.sh                    same, asks for the country code
  sudo bash MBP14_2-FIX-v5.sh --report           read-only status report, changes nothing
  sudo bash MBP14_2-FIX-v5.sh SA --force-nvram   also replace the Wi-Fi NVRAM already in place
EOF
}

# ---------- arguments ----------
MODE="setup"; COUNTRY=""; FORCE_NVRAM=0
for arg in "$@"; do
  case "$arg" in
    --report)         MODE="report" ;;
    --force-nvram)    FORCE_NVRAM=1 ;;
    -h|--help)        usage; exit 0 ;;
    [A-Za-z][A-Za-z]) COUNTRY="${arg^^}" ;;
    *)                echo "Unknown option: $arg"; usage; exit 1 ;;
  esac
done

if [[ $EUID -ne 0 ]]; then
  echo "This script needs root. Run it with sudo."
  usage
  exit 1
fi

# ---------- logging ----------
mkdir -p /var/log
exec > >(tee -a "$LOG") 2>&1
echo
echo "##### MBP14_2-FIX-v5  $STAMP  mode=$MODE  kernel=$KVER #####"

WIFI_IF="$(iw dev 2>/dev/null | awk '$1=="Interface"{print $2; exit}')"
[[ -n $WIFI_IF ]] || WIFI_IF="$(nmcli -t -f DEVICE,TYPE device 2>/dev/null | awk -F: '$2=="wifi"{print $1; exit}')"

# ---------- helpers ----------
say()  { printf '\n==> %s\n' "$*"; }
info() { printf '    %s\n' "$*"; }
warn() { printf '    !! %s\n' "$*"; }
die()  { printf '\nERROR: %s\n' "$*"; exit 1; }

ask() {                             # ask "question": success only on y / yes
  local a=""
  { true < /dev/tty; } 2>/dev/null || return 1
  read -r -p "    $1 [y/N] " a < /dev/tty
  [[ ${a,,} == y || ${a,,} == yes ]]
}

FAILED=()
step() {                            # step "title" command [args...]
  local title="$1"; shift
  say "$title"
  ( set -e; "$@" )
  local rc=$?
  if (( rc == 0 )); then info "ok"; else warn "FAILED (exit $rc): $title"; FAILED+=("$title"); fi
}

backup() {                          # copy a file into the backup dir, keeping its path
  local f="$1"
  [[ -e $f || -L $f ]] || return 0
  mkdir -p "$BACKUP_DIR$(dirname "$f")"
  cp -a "$f" "$BACKUP_DIR$f"
  info "backup: $f"
}

valid_mac() { [[ ${1:-} =~ ^([0-9a-f]{2}:){5}[0-9a-f]{2}$ ]]; }

mac_in_file() {                     # macaddr= value of an NVRAM file, lowercase
  [[ -f ${1:-} ]] || return 0
  sed -n -E 's/^[[:space:]]*macaddr=[[:space:]]*([0-9A-Fa-f:]+).*/\1/p' "$1" | head -n1 | tr 'A-F' 'a-f'
}

permanent_mac() {                   # permanent hardware address of the Wi-Fi card
  [[ -n $WIFI_IF ]] || return 0
  ethtool -P "$WIFI_IF" 2>/dev/null | awk '/[Pp]ermanent address/ { print tolower($NF) }' | tr -d '[:space:]'
}

saved_mac() {                       # MAC from the installed NVRAM or from an older backup of this machine
  local f m
  for f in "$BOARD_FW" "$GENERIC_FW"; do
    m="$(mac_in_file "$f")"
    if valid_mac "$m"; then echo "$m"; return 0; fi
  done
  while IFS= read -r f; do
    m="$(mac_in_file "$f")"
    if valid_mac "$m"; then echo "$m"; return 0; fi
  done < <(find /var/backups -type f -name 'brcmfmac43602-pcie*.txt' 2>/dev/null | sort -r)
  return 0
}

nm_connected() {
  [[ -n $WIFI_IF ]] && nmcli -t -f DEVICE,STATE device status 2>/dev/null | grep -q "^$WIFI_IF:connected"
}

git_sync() {                        # git_sync <url> <dir> [commit]
  local url="$1" dir="$2" pin="${3:-}"
  mkdir -p "$(dirname "$dir")"
  if [[ -d $dir/.git ]]; then
    git -C "$dir" fetch --quiet origin
  else
    git clone --quiet "$url" "$dir"
  fi
  if [[ -n $pin ]] && git -C "$dir" cat-file -e "$pin^{commit}" 2>/dev/null; then
    git -C "$dir" checkout --quiet --force "$pin"
  else
    [[ -n $pin ]] && warn "commit $pin not found, using the default branch"
    git -C "$dir" checkout --quiet --force origin/HEAD
  fi
  info "$(basename "$dir") at $(git -C "$dir" rev-parse --short HEAD)"
}

check_system() {
  local model
  model="$(cat /sys/class/dmi/id/product_name 2>/dev/null || echo unknown)"
  info "model: $model   kernel: $KVER   Wi-Fi interface: ${WIFI_IF:-none}"
  if [[ $model != "MacBookPro14,2" ]]; then
    warn "this script is written for MacBookPro14,2 (A1706)"
    ask "continue anyway?" || die "stopped"
  fi
  getent hosts github.com >/dev/null 2>&1 \
    || die "no internet access (git and apt need it). Connect Wi-Fi or USB-C Ethernet and run again."
}

# ---------- steps ----------
install_base_packages() {
  export DEBIAN_FRONTEND=noninteractive
  apt-get update || warn "apt update reported errors, continuing"
  apt-get install -y git wget patch make gcc build-essential dkms \
    ethtool iw pciutils usbutils network-manager
}

install_kernel_packages() {
  export DEBIAN_FRONTEND=noninteractive
  apt-get install -y "linux-headers-$KVER" "linux-source-$KBASE"
}

fetch_sources() {
  git_sync "$VENDOR_URL" "$VENDOR_DIR"
  git_sync "$CIRRUS_URL" "$CIRRUS_DIR" "$CIRRUS_PIN"
}

drop_shadowing_firmware() {         # an unpackaged uncompressed .bin overrides the packaged .bin.zst
  if [[ -f $PACKAGED_BIN ]] && ! dpkg -S "$PACKAGED_BIN" >/dev/null 2>&1 \
     && compgen -G "$PACKAGED_BIN.*" >/dev/null; then
    warn "unpackaged $PACKAGED_BIN overrides the packaged firmware: moving it to the backup"
    backup "$PACKAGED_BIN"
    rm -f "$PACKAGED_BIN"
  fi
  return 0
}

install_wifi_nvram() {
  local src pm mac cur tmp
  drop_shadowing_firmware

  src="$(find "$VENDOR_DIR" -type f -iname 'brcmfmac43602-pcie*MacBookPro14,2*.txt' 2>/dev/null | head -n1)"
  [[ -n $src ]] || { warn "NVRAM file not found in the repository"; return 1; }
  info "repository file: ${src#"$VENDOR_DIR"/}"

  pm="$(permanent_mac)"
  if valid_mac "$pm"; then
    mac="$pm"
  else
    mac="$(saved_mac)"
    valid_mac "$mac" || { warn "cannot read the permanent MAC (Wi-Fi interface: ${WIFI_IF:-none}); NVRAM unchanged"; return 1; }
    warn "permanent MAC not readable right now; using the MAC already stored on this machine"
  fi

  cur="$BOARD_FW"; [[ -f $cur ]] || cur="$GENERIC_FW"
  if (( FORCE_NVRAM == 0 )) && [[ -n $WIFI_IF && -f $cur ]] \
     && valid_mac "$pm" && [[ "$(mac_in_file "$cur")" == "$pm" ]]; then
    info "Wi-Fi interface $WIFI_IF exists and its NVRAM already has the permanent MAC: keeping it"
    info "(add --force-nvram to replace it with the repository file)"
    return 0
  fi

  tmp="$(mktemp)"
  tr -d '\r' < "$src" > "$tmp"
  if grep -Eq '^[[:space:]]*macaddr=' "$tmp"; then
    sed -i -E "s/^[[:space:]]*macaddr=.*/macaddr=$mac/" "$tmp"
  else
    printf '\nmacaddr=%s\n' "$mac" >> "$tmp"
  fi
  backup "$BOARD_FW"
  backup "$GENERIC_FW"
  install -D -m 0644 "$tmp" "$BOARD_FW"
  install -D -m 0644 "$tmp" "$GENERIC_FW"
  rm -f "$tmp"
  info "NVRAM installed as the board-specific file and as the generic fallback"
}

wifi_config() {
  local f
  for f in "$MODPROBE_DIR"/10-wifi-regdom*.conf; do
    [[ -e $f && $f != "$REGDOM_CONF" ]] || continue
    backup "$f"
    rm -f "$f"
    info "removed older regulatory file: $f"
  done
  backup "$REGDOM_CONF"
  printf 'options cfg80211 ieee80211_regdom=%s\n' "$COUNTRY" > "$REGDOM_CONF"
  info "regulatory domain: $COUNTRY"

  mkdir -p "$(dirname "$NM_CONF")"
  backup "$NM_CONF"
  printf '[device]\nwifi.scan-rand-mac-address=no\n' > "$NM_CONF"
  info "NetworkManager: scan MAC randomization off"
}

wifi_profile() {
  local con
  con="$(nmcli -t -f NAME,TYPE connection show --active 2>/dev/null | awk -F: '$NF=="802-11-wireless" {print $1; exit}')"
  if [[ -z $con ]]; then
    warn "no active Wi-Fi connection now. After you connect, run:"
    warn "nmcli connection modify \"<name>\" connection.autoconnect yes 802-11-wireless.cloned-mac-address permanent"
    return 0
  fi
  nmcli connection modify "$con" connection.autoconnect yes 802-11-wireless.cloned-mac-address permanent
  info "profile \"$con\": autoconnect on, permanent MAC"
}

touchbar_driver() {
  local name deb

  # other Touch Bar DKMS modules (for example apple_touchbar) can fight over the same hardware
  while IFS= read -r name; do
    [[ -n $name && $name != mbp-t1-touchbar/* ]] || continue
    warn "another Touch Bar DKMS module is installed: $name"
    if ask "remove $name from DKMS for all kernels?"; then
      dkms remove "$name" --all || warn "could not remove $name"
    fi
  done < <(dkms status 2>/dev/null | cut -d, -f1 | grep -Ei 'touch|ibridge|apple.?ib' | sort -u)

  # build the packaged driver from the repository; fall back to an existing .deb
  if [[ -f $VENDOR_DIR/touchbar/build.sh ]]; then
    ( cd "$VENDOR_DIR/touchbar" && bash build.sh ) || warn "build.sh failed, looking for an existing .deb"
  fi
  deb="$(find "$VENDOR_DIR" -type f -name 'mbp-t1-touchbar-dkms*.deb' -printf '%T@ %p\n' 2>/dev/null \
         | sort -rn | head -n1 | cut -d' ' -f2-)"
  [[ -n $deb ]] || { warn "no mbp-t1-touchbar-dkms .deb found"; return 1; }
  info "installing ${deb#"$VENDOR_DIR"/}"
  DEBIAN_FRONTEND=noninteractive apt-get install -y "$deb"
  dkms status 2>/dev/null | grep -i 'mbp-t1-touchbar' | sed 's/^/    dkms: /'

  # module options (the repo keeps them in /etc/modprobe.d/mbp-t1-touchbar.conf)
  backup "$TB_CONF"
  if [[ -f $TB_CONF ]] && grep -Eq '^[[:space:]]*options[[:space:]]+apple[-_]ib[-_]tb' "$TB_CONF"; then
    sed -i -E "s/^[[:space:]]*options[[:space:]]+apple[-_]ib[-_]tb.*/$TB_OPTS/" "$TB_CONF"
  else
    echo "$TB_OPTS" >> "$TB_CONF"
  fi
  info "$TB_OPTS"

  if systemctl cat mbp-t1-touchbar-bind.service >/dev/null 2>&1; then
    systemctl enable mbp-t1-touchbar-bind.service
  else
    warn "mbp-t1-touchbar-bind.service not found after install"
  fi
  if lsusb 2>/dev/null | grep -qi '05ac:1281'; then
    warn "iBridge is in Recovery Mode (05ac:1281): boot macOS once so it restores the T1 firmware"
  fi
}

audio_driver() {
  [[ -f $CIRRUS_DIR/install.cirrus.driver.sh ]] || { warn "install.cirrus.driver.sh not found"; return 1; }
  (
    cd "$CIRRUS_DIR" || exit 1
    bash ./install.cirrus.driver.sh -r >/dev/null 2>&1 || true   # drop an older DKMS build, if any
    bash ./install.cirrus.driver.sh -i
  )
  dkms status -m snd_hda_macbookpro 2>/dev/null | sed 's/^/    dkms: /'
  dkms status -m snd_hda_macbookpro 2>/dev/null | grep -q "$KVER.*: installed"
}

report() {
  local cur pm same
  say "System"
  info "model: $(cat /sys/class/dmi/id/product_name 2>/dev/null)   kernel: $KVER"
  info "boot args: $(cat /proc/cmdline)"
  info "suspend mode: $(cat /sys/power/mem_sleep 2>/dev/null)"

  say "Wi-Fi"
  lspci -nnk -d 14e4:43ba 2>/dev/null | sed 's/^/    /'
  info "interface: ${WIFI_IF:-none}   connected: $(nm_connected && echo yes || echo no)"
  cur="$BOARD_FW"; [[ -f $cur ]] || cur="$GENERIC_FW"
  if [[ -f $cur ]]; then
    pm="$(permanent_mac)"; same="no"
    [[ -n $pm && "$(mac_in_file "$cur")" == "$pm" ]] && same="yes"
    info "NVRAM: $(basename "$cur")   macaddr matches the permanent address: $same"
  else
    info "NVRAM: missing"
  fi
  if iw list 2>/dev/null | grep -q 'Band 2'; then info "5 GHz band exposed: yes"; else info "5 GHz band exposed: no"; fi

  say "Touch Bar"
  lsusb 2>/dev/null | grep -Ei '05ac:(8600|1281)' | sed 's/^/    /'
  lsmod | grep -E '^apple_(ibridge|ib_tb|ib_als) ' | awk '{ print "    loaded: " $1 }'
  info "service: $(systemctl is-active mbp-t1-touchbar-bind.service 2>/dev/null)"
  dkms status 2>/dev/null | grep -Ei 'touch|ibridge|apple.?ib' | sed 's/^/    dkms: /'

  say "Audio"
  lsmod | grep -i cs8409 | awk '{ print "    loaded: " $1 }'
  dkms status -m snd_hda_macbookpro 2>/dev/null | sed 's/^/    dkms: /'
  return 0
}

summary() {
  say "Summary"
  if (( ${#FAILED[@]} > 0 )); then
    warn "failed steps: $(printf '%s; ' "${FAILED[@]}")"
    warn "fix the cause shown above (full log: $LOG) and run the script again"
  else
    info "all steps finished"
  fi
  [[ -d $BACKUP_DIR ]] && info "files replaced in this run were copied to: $BACKUP_DIR"
  info "after reboot: Settings > Sound > Output = Analogue Stereo Output (Duplex if you need the mic)"
  info "Touch Bar still dark? sudo systemctl restart mbp-t1-touchbar-bind.service"
  info "never play test sound through hw:0,0 or plughw:0,0 (no volume control there)"
  info "status check: sudo bash MBP14_2-FIX-v5.sh --report"
  return 0
}

# ---------- main ----------
if [[ $MODE == report ]]; then
  report
  exit 0
fi

if [[ -z $COUNTRY ]]; then
  read -r -p "Wi-Fi country code (2 letters, e.g. JP, SA, AE, EG, US): " COUNTRY < /dev/tty
  COUNTRY="${COUNTRY^^}"
fi
[[ $COUNTRY =~ ^[A-Z]{2}$ ]] || die "'$COUNTRY' is not a 2-letter country code"

check_system
step "Base packages"                                    install_base_packages
step "Kernel headers and source for $KVER"              install_kernel_packages
step "Sources: vfontanela repo, davidjo repo at cb27cc4" fetch_sources
step "Wi-Fi: board NVRAM with the permanent MAC"        install_wifi_nvram
step "Wi-Fi: regulatory domain and NetworkManager"      wifi_config
step "Wi-Fi: active connection"                         wifi_profile
step "Touch Bar (T1 iBridge)"                           touchbar_driver
step "Internal audio (CS8409)"                          audio_driver
step "Rebuild initramfs"                                update-initramfs -u -k all
summary
ask "Reboot now to apply everything?" && systemctl reboot
exit 0
