# MacBookPro14,2 (A1706) — Ubuntu 26.04.1 Linux fixes

**Hardware-specific, experimental recovery toolkit** for the **2017 13-inch MacBook Pro with Touch Bar, model MacBookPro14,2 (A1706, Apple T1)**. This project consolidates a working user's troubleshooting and the earlier `MBP14_2-FIX-v5.sh` installer. It is **not** an official Apple/Ubuntu installer, and does **not** promise perfection on all MacBooks.

> **UPDATE — 2026-10-24, v5.2 testing:** The owner reported that Touch Bar **brightness, volume and Fn controls now work** after applying the T1 `usb_control_msg()` return-value normalization patch and rebooting. Previously, the display lit after ACPI wake but input events were `KEY_UNKNOWN`. This is one-device feedback, **not** a long-term stability or clean-install guarantee. The integrated v5.2 installer has static/synthetic tests only. See [technical explanation](docs/TECHNICAL-NOTES.md#5-t1-usb-mode-success-code-and-key_unknown-root-cause).

> **TESTED IN ONE REAL ENVIRONMENT:** Ubuntu **26.04.1**, Linux **7.0.0-38-generic**, Broadcom **BCM43602 14e4:43ba**, Cirrus **CS8409**, Apple T1 **05ac:8600**, internal NVMe **0000:01:00.0**. Tested success was reported by the device owner on **2026-10-24**. Different firmware, Ubuntu versions or kernels may behave differently. No lab or CI hardware tests have been run on this packaged release.

## Support matrix

| Component | Applied fix | Observed result / limitation |
|---|---|---|
| BCM43602 Wi-Fi | Preserve verified board NVRAM and local MAC; `roamoff=1 feature_disable=0x2000`; PCI remove/rescan **10 seconds after cold boot only if disconnected** | Owner observed association works after PCI re-enumeration. Uses PCI slot `0000:02:00.0` as observed. |
| NVMe / S3 sleep | `nvme-d3cold.service` keeps `d3cold_allowed=0` on PCI `0000:01:00.0`; `MemorySleepMode=deep` | Deep sleep/resume reported working. |
| Internal CS8409 audio | Community `snd_hda_macbookpro/0.1`, pinned base `cb27cc4`; pinned PR #220 header `b8bc4d9` | Owner reported working sound across S3. **Audio helper is pinned to kernel 7.0.0-38**. |
| T1 Touch Bar / input | `apple-ib-drv/0.1`; T1-aware `.resume`, mode-only T1 guard and T1 `usb_control_msg()` return-value normalization (`1` transferred byte -> `0` success) | On the tested machine, owner subsequently confirmed buttons working after applying the USB fix; previous S3 tests showed `KEY_UNKNOWN`. Needs broader validation. |
| T1 display after deep S3 | **Optional** ACPI `ASOC.SOCW(1)` **once, five seconds after wake**, via systemd hook and oneshot service | Display illumination confirmed. Full keys also require the T1 USB return-code fix; ACPI still carries **hard-freeze risk**. |
| USB T1 runtime power | udev `ENV{DEVTYPE}=="usb_device"` rule, `power/control=on` | Corrects an earlier invalid `DEVTYPE` syntax. |
| Thunderbolt/USB-C | No changes | Kernel warnings (`tb_cfg_read/write`) seen after S3; not proven to cause perceptible delay. |

## Read this first — critical warnings

- **`ASOC.SOCW(1)` CAN HARD-FREEZE some Apple T1 devices.** The default installer **never enables** the ACPI wake workaround. It requires an **explicit acknowledgement and separate command**, only after first trying a manual wake on the exact model/firmware. It does not run from the touchbar driver probe; keep `skip_acpi_power=1`. Never use `skip_acpi_power=0`.
- PCI Wi-Fi recovery briefly removes and rescans **only PCI slot 0000:02:00.0**. The service skips recovery if NetworkManager reports Wi-Fi connected, and it runs once 10 seconds after boot (not periodically). It is **not** safe to port to another machine/slot unchanged.
- **Never publish personalized Wi-Fi NVRAM `.txt` files**, network MAC addresses, serial numbers, activation records, or raw diagnostic logs. The repository includes no firmware or private calibration.
- The old `mbp-t1-touchbar-bind.service` targets module `apple-ib-tb` and is deliberately disabled/masked when safe; **never** revive it on this DKMS installation. Never unbind/rebind T1 HID repeatedly (`-17` duplicate registrations observed).
- **Do not run the installer from a USB-C Ethernet-only emergency session** without preparing for possible Wi-Fi/USB interruptions and having a backup route. Read commands before executing them as root.
- External driver projects retain their own licences. Review their code before use. The script will **not execute external driver installers** unless `--allow-upstream-installers` is explicitly provided; the T1 upstream installer on its default branch is **not commit-pinned**, so a fresh installation is less reproducible than reusing an existing DKMS tree.

## Files

| File | Purpose |
|---|---|
| `MBP14_2-FIX-v5.sh` | Main rerunnable installer / report / T1 wake toggle. Replaces the previous v5 logic. |
| `MBP14_2-CS8409-PR220.sh` | Pinned audio source/header, backup, check, install and rollback helper; required by main installer for PR #220. |
| `MBP14_2-T1-USB-RETURN-FIX.sh` | Standalone, tested-on-one-machine T1 USB mode success-code patch with `--check`, `--apply`, `--rollback` (main installer also includes the fix). |
| `README.ar.md` | Arabic setup and troubleshooting documentation. |
| `tools/check-touchbar-input.sh` | Read-only input inventory and optional 15-second `evtest` test after S3 (no ACPI writes). |
| `docs/TROUBLESHOOTING.md` | Failure cases, power-safety caveats, logs and rollback. |
| `docs/TECHNICAL-NOTES.md` | Exact root causes, callbacks, timings, decisions and credits. |
| `legacy/MBP14_2-FIX-v5-original.sh` | Preserved original v5 for reference only. **Do not run it** on the working machine. |

## Quick start — existing MacBook already working

```bash
# Clone or extract this full repository; the audio helper must stay alongside the main script.
chmod +x MBP14_2-FIX-v5.sh MBP14_2-CS8409-PR220.sh
sudo bash ./MBP14_2-FIX-v5.sh --report
sudo bash ./MBP14_2-FIX-v5.sh --install --country AE
# Select YOUR legally correct two-letter regulatory domain; AE is a proven
# machine-specific prior setting, NOT a generic suggestion for other countries.
# Review the output, then reboot manually when appropriate.
```

The default `--report` is **read-only**; installing a second time avoids replacing already verified NVRAM, already patched T1/audio sources, or an existing NVMe service. Files that the script writes are saved under `/var/backups/mbp14-2-v5.2/<run>/`. It won't automatically reboot. The **10-second Wi-Fi timer is only enabled for the next boot**, not started live.

**Fresh installs (review the external installers first):**

```bash
sudo bash ./MBP14_2-FIX-v5.sh --install --country XX --allow-upstream-installers
```

Replace `XX` with your applicable country code. This optionally fetches and runs the community **T1** and **audio** installers if the DKMS versions are not installed. **Do not use that flag on an existing functioning machine.** Missing hardware-specific MAC calibration causes a protective skip rather than guessing.

### Opt-in: T1 firmware wake after S3 (dangerous)

**ONLY** after validating the precise ACPI path and testing a single manual `SOCW(1)` successfully on your own T1 machine, and ensuring the Touch Bar DKMS and USB enumeration work, install `acpi-call-dkms` if required:

```bash
sudo apt install acpi-call-dkms
sudo bash ./MBP14_2-FIX-v5.sh --enable-t1-wake --acknowledge-acpi-risk
```

**NOTE:** ACPI only restores firmware-level display illumination. The separate **USB return-code driver patch** is required for input state to recover; the owner reports this combination now works after S3. Never treat the ACPI success log alone as proof of functioning keys.

This creates `/usr/lib/systemd/system-sleep/95-mbp-t1-wake` which dispatches `mbp-t1-fast-wake.service` asynchronously. The service **waits five seconds**, then checks `skip_acpi_power=1` and USB ID `05ac:8600` on `1-3`, sends **one** `ASOC.SOCW(1)` command and requests the `apple-touchbar` display to stay lit. **Do not enable on other models or without accepting the risk of hard lock / lost unsaved work.** It neither repeats the ACPI call nor resets the USB host.

To turn it off:

```bash
sudo bash ./MBP14_2-FIX-v5.sh --disable-t1-wake
```

Use this if stability deteriorates. Never turn this into a loop or driver-probe power call.

## Maintenance and verification

```bash
sudo bash ./MBP14_2-FIX-v5.sh --report
systemctl list-timers --all | grep mbp-bcm43602
systemctl status nvme-d3cold.service --no-pager
cat /sys/power/mem_sleep                        # s2idle [deep]
cat /sys/module/apple_ibridge/parameters/skip_acpi_power  # 1
sudo journalctl -b -u mbp-t1-fast-wake.service --no-pager
sudo journalctl -b -k --no-pager | grep -E 'Touchbar resumed|PM: suspend'
```

The integrated `apple-ib-drv/0.1` source patch combines (1) T1-aware resume interface condition, (2) `.resume` callback and (3) `usb_control_msg()` return-value normalization for the 1-byte T1 mode command. The third fix makes `appletb_set_tb_worker()` see `rc1 == 0`, so it can update `cur_tb_mode` rather than leaving the bar in the `OFF` state and sending `KEY_UNKNOWN`. Re-running the main installer recognizes marker `MBP14_2_T1_USB_RC_NORMALIZATION` and skips a rebuild if the source is already patched. **Source patched does not prove the booted DKMS image contains it; reboot and test.** The source patch is stored under `/usr/src`; after driver-source replacement or kernel upgrades inspect `dkms status` and re-run `--report`. The helper `--restore-t1-source` restores a backup generated **by this updated installer**; it does not guess the state of a third-party DKMS tree.

### Audio rollback (pinned helper)

```bash
sudo bash ./MBP14_2-CS8409-PR220.sh --status
sudo bash ./MBP14_2-CS8409-PR220.sh --rollback  # only if that helper previously installed the patch
# then manually reboot
```

See [Troubleshooting](docs/TROUBLESHOOTING.md) for Wi-Fi recovery, DKMS failures, and safe disabling of the ACPI hook.

## Source credit and licensing

This package orchestrates, but **does not vendor**, external project code or calibration:

- [vfontanela/macbookpro14-linux-support](https://github.com/vfontanela/macbookpro14-linux-support) — basis for original v5 and MacBook hardware notes.
- [nohzafk/omarchy-macbookpro-t1](https://github.com/nohzafk/omarchy-macbookpro-t1) — pinned Broadcom NVRAM source (validated against Git blob before changing its `macaddr`).
- [davidjo/snd_hda_macbookpro](https://github.com/davidjo/snd_hda_macbookpro) — Cirrus CS8409 audio driver, pinned base `cb27cc4`, PR #220 header `b8bc4d9`.
- [AJ-dev-i60/t1-touchbar](https://github.com/AJ-dev-i60/t1-touchbar) — kernel-7-compatible Apple T1 `apple-ib-drv/0.1` DKMS fork.
- [roadrunner2's Linux MacBook notes](https://gist.github.com/roadrunner2/1289542a748d9a104e7baec6a92f9cd7) — historical Apple iBridge background.

The orchestration/docs in this package are offered under the **MIT licence**, found in `LICENSE`. All upstream sources and kernel components remain under their respective licences. No Apple firmware, non-redistributable calibration, or user-specific data is included.

## Validation status

`bash -n` and local non-invasive static checks have been run against the packaged scripts. **No local hardware was available to execute the installer in this environment; the finished integrated script has not been exercised end-to-end on Mac hardware.** The observed device-specific behavior above comes from the user's terminal logs and manual tests, not an independent hardware regression suite. Contributions, especially tested kernel revisions, are welcome.

For a ready-to-publish GitHub workflow see [Publishing guide](docs/GITHUB-PUBLISHING.md). A project-local CI or real-hardware test is encouraged before tagging a production release.
