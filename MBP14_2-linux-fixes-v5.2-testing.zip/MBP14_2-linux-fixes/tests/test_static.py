"""Non-destructive packaging tests. Do NOT execute root installer in CI."""
from pathlib import Path
import subprocess
import unittest

ROOT = Path(__file__).resolve().parents[1]
MAIN = ROOT / 'MBP14_2-FIX-v5.sh'
AUDIO = ROOT / 'MBP14_2-CS8409-PR220.sh'


class Packaging(unittest.TestCase):
    def test_scripts_parse(self):
        for path in (MAIN, AUDIO, ROOT / 'MBP14_2-T1-USB-RETURN-FIX.sh'):
            p = subprocess.run(['bash', '-n', str(path)], capture_output=True, text=True)
            self.assertEqual(p.returncode, 0, p.stderr)

    def test_help_safe(self):
        p = subprocess.run(['bash', str(MAIN), '--help'], capture_output=True, text=True)
        self.assertEqual(p.returncode, 0)
        self.assertIn('--enable-t1-wake', p.stdout)

    def test_report_cannot_accidentally_install_with_country(self):
        p = subprocess.run(['bash', str(MAIN), '--report', '--country', 'AE'],
                           capture_output=True, text=True)
        self.assertEqual(p.returncode, 0, p.stderr)
        self.assertIn('Report:', p.stdout)

    def test_conflicting_modes_rejected(self):
        p = subprocess.run(['bash', str(MAIN), '--report', '--install'],
                           capture_output=True, text=True)
        self.assertNotEqual(p.returncode, 0)
        self.assertIn('exactly one mode', p.stderr)

    def test_baseline_changes_present(self):
        text = MAIN.read_text()
        for token in ('OnBootSec=10s', 'AccuracySec=1s',
                      'd3cold_allowed', 'MemorySleepMode=deep',
                      'tb_dev->is_t1 ||', 'skip_acpi_power=1',
                      'ENV{DEVTYPE}', 'ExecStartPre=/usr/bin/sleep 5',
                      'MBP14_2_T1_USB_RC_NORMALIZATION', 'if (rc == 1)',
                      '--acknowledge-acpi-risk', 'ACPI result:'):
            self.assertIn(token, text)
        self.assertIn('MBP14_2-CS8409-PR220.sh', text)

    def test_no_private_files(self):
        self.assertFalse(list(ROOT.rglob('*.pem')))
        self.assertFalse(list(ROOT.rglob('*.bin')))


if __name__ == '__main__':
    unittest.main()

# Additional CLI guard exercised without sudo/mounts/hardware.
