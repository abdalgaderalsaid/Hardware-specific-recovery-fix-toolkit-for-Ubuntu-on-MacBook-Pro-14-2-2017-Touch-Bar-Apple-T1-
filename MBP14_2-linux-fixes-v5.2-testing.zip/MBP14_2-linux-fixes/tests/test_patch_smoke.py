"""Test the embedded source transformation on synthetic code, never touch DKMS."""
from pathlib import Path
import re
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
MAIN = ROOT / 'MBP14_2-FIX-v5.sh'


def embedded_patch():
    match = re.search(r'changed="\$\(python3 - "\$TB_SRC" "\$SAVE" <<\'PY\'\n(.*?)\nPY\n\)"',
                      MAIN.read_text(), re.S)
    if not match:
        raise AssertionError('Embedded Python source patch missing')
    return match.group(1)


SOURCE = '''static int appletb_set_tb_mode(struct appletb_device *tb_dev, unsigned char mode)
{
    int tries = 0;
    int rc;
    do {
        rc = usb_control_msg(dev, pipe, request, type, value, index, buf, 1, 2000);
        if (rc != -EPIPE)
            break;
        usleep_range(1000, 3000);
    } while (++tries < 5);
    return rc;
}

static int appletb_set_tb_disp(struct appletb_device *tb_dev, unsigned char disp)
{
    return 0;
}

static void appletb_set_tb_worker(struct appletb_device *tb_dev)
{
    if (rc1 == 0) {
        tb_dev->cur_tb_mode = pending_mode;
    }
}

static int appletb_reset_resume(struct hid_device *hdev)
{
    if ((tb_dev->mode_iface.hdev && !tb_dev->mode_iface.suspended) &&
\t    (tb_dev->disp_iface.hdev && !tb_dev->disp_iface.suspended)) {
        do_work();
    }
    return 0;
}
#endif

static struct hid_driver appletb_hid_driver = {
\t.suspend = appletb_suspend,
\t.reset_resume = appletb_reset_resume,
};
'''


class TouchBarPatch(unittest.TestCase):
    def run_patch(self, source):
        with tempfile.TemporaryDirectory() as temp:
            file = Path(temp) / 'apple-touchbar.c'
            file.write_text(source)
            results = []
            for _ in (0, 1):
                results.append(subprocess.run(
                    ['python3', '-', str(file), temp], input=embedded_patch(),
                    text=True, capture_output=True))
            text = file.read_text()
            original = (Path(temp) / 't1-source/apple-touchbar.c.before')
            return results, text, original.exists() and original.read_text() == source

    def test_full_patch_and_idempotence(self):
        results, result, backed_up = self.run_patch(SOURCE)
        self.assertEqual([r.returncode for r in results], [0, 0])
        self.assertEqual([r.stdout.strip() for r in results], ['patched', 'unchanged'])
        self.assertTrue(backed_up)
        self.assertIn('tb_dev->is_t1 ||', result)
        self.assertIn('.resume = appletb_reset_resume,', result)
        self.assertEqual(result.count('MBP14_2_T1_USB_RC_NORMALIZATION'), 1)
        self.assertIn('if (rc == 1)', result)
        self.assertIn('else if (rc >= 0)', result)

    def test_unknown_layout_fails_closed(self):
        results, text, backed_up = self.run_patch(SOURCE.replace('} while (++tries < 5);', '} while (++tries < 9);'))
        self.assertNotEqual(results[0].returncode, 0)
        self.assertIn('retry-loop', results[0].stderr)
        self.assertFalse(backed_up)
        self.assertNotIn('MBP14_2_T1_USB_RC_NORMALIZATION', text)

    def test_marker_lying_fails_closed(self):
        source = SOURCE.replace('    return rc;\n}', '    /* MBP14_2_T1_USB_RC_NORMALIZATION */\n    return rc;\n}', 1)
        results, _, backed_up = self.run_patch(source)
        self.assertNotEqual(results[0].returncode, 0)
        self.assertIn('marker present', results[0].stderr)
        self.assertFalse(backed_up)


if __name__ == '__main__':
    unittest.main()
