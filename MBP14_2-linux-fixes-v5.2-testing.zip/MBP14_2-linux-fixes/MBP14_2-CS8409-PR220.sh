#!/usr/bin/env bash
# MacBookPro14,2 / Ubuntu 26.04 / 7.0.0-38-generic
# CS8409 deep-sleep resume repair using PR #220 pinned at b8bc4d9.
# Requires an existing snd_hda_macbookpro/0.1 installation from cb27cc4.
# Usage: sudo bash MBP14_2-CS8409-PR220.sh --check|--install|--rollback|--status
# Only touches snd_hda_macbookpro's source header, its DKMS build, and the
# resulting CS8409 module. Does NOT change Wi-Fi/NVRAM, NVMe, Touch Bar, or GRUB.
set -Eeuo pipefail
umask 077

SRC='/usr/local/src/mbp14-2/snd_hda_macbookpro'
HEADER="$SRC/patch_cirrus/cirrus_apple.h"
DKMS_CONF="$SRC/dkms.conf"
BACKUP='/var/backups/mbp14-2-cs8409-pr220'
KERNEL='7.0.0-38-generic'
DKMS_NAME='snd_hda_macbookpro'
DKMS_VERSION='0.1'
MODULE_NAME='snd_hda_codec_cs8409'
SOURCE_REV='cb27cc483f4fe98be03a4f4bef466c00aa7d244b'
PR_HEAD='b8bc4d935335a9a5476c478d491adf9b18012f58'
OLD_BLOB='7e9bcd1f6ff4e4ac76e3134c3440b7d9cf68bc0f'
NEW_BLOB='116f62e8af7b9055357968b911dc75aa4286be4b'
PR_FILE="https://raw.githubusercontent.com/davidjo/snd_hda_macbookpro/${PR_HEAD}/patch_cirrus/cirrus_apple.h"
MODE="${1:---help}"
MODULE_FILE=''
TMP=''
IN_TRANSACTION=0

log() { printf '[CS8409] %s\n' "$*"; }
err() { printf '[CS8409] ERROR: %s\n' "$*" >&2; exit 1; }
usage() {
  cat <<'EOF'
Usage:
  sudo bash MBP14_2-CS8409-PR220.sh --check      # Preflight + verify pinned PR file. No changes.
  sudo bash MBP14_2-CS8409-PR220.sh --install    # Backup, build, install new DKMS module. Reboot manually.
  sudo bash MBP14_2-CS8409-PR220.sh --rollback   # Restore original source and installed module. Reboot manually.
  sudo bash MBP14_2-CS8409-PR220.sh --status     # Read-only status.

Scope: audio CS8409 only, kernel 7.0.0-38-generic; no change to other hardware.
Notes: PR #220 was OPEN / not merged as of 2026-10-23. This is an experimental
       upstream change, not validated here on MacBookPro14,2 hardware.
EOF
}

cleanup() {
  local rc=$?
  trap - EXIT
  if (( rc != 0 && IN_TRANSACTION == 1 )); then
    log 'Installation failed; restoring saved source and installed driver...'
    if [[ -f "$BACKUP/cirrus_apple.h.original" ]]; then
      cp -a -- "$BACKUP/cirrus_apple.h.original" "$HEADER" || true
    fi
    if [[ -f "$BACKUP/dkms.conf.original" ]]; then
      cp -a -- "$BACKUP/dkms.conf.original" "$DKMS_CONF" || true
    fi
    if [[ -f "$BACKUP/module.original" && -n "$MODULE_FILE" ]]; then
      cp -a -- "$BACKUP/module.original" "$MODULE_FILE" || true
      depmod -a "$KERNEL" || true
    fi
    log "Original file backups retained at $BACKUP"
    log 'If you experience audio issues, reboot; you may then run --rollback.'
  fi
  [[ -z "$TMP" || ! -d "$TMP" ]] || rm -rf -- "$TMP"
  exit "$rc"
}
trap cleanup EXIT

[[ $# == 1 ]] || { usage; exit 2; }
case "$MODE" in
  --help|-h) usage; exit 0 ;;
  --check|--install|--rollback|--status) ;;
  *) usage; exit 2 ;;
esac

for tool in git dkms modinfo cp cat uname; do
  command -v "$tool" >/dev/null 2>&1 || err "missing $tool"
done

if [[ $MODE == --status ]]; then
  log "Current kernel: $(uname -r)"
  log "Header: $(git hash-object "$HEADER" 2>/dev/null || echo missing)"
  log "DKMS status:"
  dkms status -m "$DKMS_NAME" || true
  log "Installed module path: $(modinfo -n "$MODULE_NAME" 2>/dev/null || echo missing)"
  [[ ! -f "$BACKUP/installed" ]] || log "PR #220 installation recorded: $(cat "$BACKUP/installed")"
  exit 0
fi

(( EUID == 0 )) || err 'Run with sudo.'
[[ "$(cat /sys/class/dmi/id/product_name 2>/dev/null)" == 'MacBookPro14,2' ]] || err 'Not MacBookPro14,2; stopping.'
[[ "$(uname -r)" == "$KERNEL" ]] || err "This package is for $KERNEL only. Running: $(uname -r)"

if [[ $MODE == --rollback ]]; then
  [[ -f "$BACKUP/cirrus_apple.h.original" && -f "$BACKUP/module.original" && -f "$BACKUP/module-path" ]] || err "No complete original backup in $BACKUP"
  [[ "$(git hash-object "$BACKUP/cirrus_apple.h.original")" == "$OLD_BLOB" ]] || err 'Original header backup checksum mismatch.'
  MODULE_FILE="$(cat "$BACKUP/module-path")"
  [[ "$MODULE_FILE" == "/lib/modules/$KERNEL/updates/dkms/"* || "$MODULE_FILE" == "/usr/lib/modules/$KERNEL/updates/dkms/"* ]] || err 'Unsafe original module path in backup. Stopping.'
  log 'Restoring original source and driver (no other hardware settings affected).'
  cp -a -- "$BACKUP/cirrus_apple.h.original" "$HEADER"
  [[ ! -f "$BACKUP/dkms.conf.original" ]] || cp -a -- "$BACKUP/dkms.conf.original" "$DKMS_CONF"
  # Refresh DKMS state against the restored source. If this fails, restore the
  # original known-working installed .ko anyway; do not hide the failure.
  REBUILD_OK=1
  if ! dkms build -m "$DKMS_NAME" -v "$DKMS_VERSION" -k "$KERNEL" --force; then
    REBUILD_OK=0
    log 'WARNING: rollback DKMS rebuild failed; restoring binary backup.'
  elif ! dkms install -m "$DKMS_NAME" -v "$DKMS_VERSION" -k "$KERNEL" --force; then
    REBUILD_OK=0
    log 'WARNING: rollback DKMS install failed; restoring binary backup.'
  fi
  cp -a -- "$BACKUP/module.original" "$MODULE_FILE"
  depmod -a "$KERNEL"
  rm -f -- "$BACKUP/installed"
  log 'Original .h and module binary restored. Reboot to load original audio module.'
  (( REBUILD_OK == 1 )) || log 'WARNING: DKMS metadata may need attention after reboot (original .ko restored).'
  exit 0
fi

# Common preflight for --check and --install
[[ -f "$HEADER" && -f "$DKMS_CONF" ]] || err "Missing expected source under $SRC"
[[ "$(readlink -f /usr/src/snd_hda_macbookpro-0.1 2>/dev/null)" == "$(readlink -f "$SRC")" ]] || err "DKMS source is not linked to $SRC. Refusing to patch an unrelated checkout."
[[ "$(readlink -f /var/lib/dkms/snd_hda_macbookpro/0.1/source 2>/dev/null)" == "$(readlink -f "$SRC")" ]] || err "DKMS registry references a different audio source. Stopping."
[[ "$(git -C "$SRC" rev-parse HEAD 2>/dev/null)" == "$SOURCE_REV" ]] || err 'Source repository commit is not cb27cc4; refusing to overwrite.'
[[ "$(git hash-object "$HEADER")" == "$OLD_BLOB" ]] || err 'The local CS8409 source was already changed; refusing to overwrite.'
[[ ! -f "$BACKUP/installed" ]] || err 'PR #220 is already recorded installed. Use --status/--rollback.'
[[ -d "/lib/modules/$KERNEL/build" ]] || err 'Kernel headers are missing.'
[[ -f '/usr/src/linux-source-7.0.0.tar.bz2' ]] || err 'Ubuntu linux-source-7.0.0.tar.bz2 is missing.'
[[ -d /usr/lib/dkms || -d /var/lib/dkms ]] || err 'Missing DKMS working directory.'
DKMS_STATUS="$(dkms status -m "$DKMS_NAME" -v "$DKMS_VERSION" -k "$KERNEL" || true)"
[[ "$DKMS_STATUS" == *"$KERNEL"* && "$DKMS_STATUS" == *'installed'* ]] || err "DKMS not installed for $KERNEL: $DKMS_STATUS"
MODULE_FILE="$(modinfo -n "$MODULE_NAME" 2>/dev/null || true)"
[[ "$MODULE_FILE" == "/lib/modules/$KERNEL/updates/dkms/"* || "$MODULE_FILE" == "/usr/lib/modules/$KERNEL/updates/dkms/"* ]] || err "CS8409 module is not the expected DKMS module: $MODULE_FILE"
[[ -f "$MODULE_FILE" ]] || err "Module file not found: $MODULE_FILE"
MODULE_VERMAGIC="$(modinfo -F vermagic "$MODULE_NAME" 2>/dev/null || true)"
[[ "$MODULE_VERMAGIC" == "$KERNEL "* ]] || err "CS8409 module vermagic does not match running kernel: $MODULE_VERMAGIC"
command -v curl >/dev/null || err 'curl is required to download exact PR file.'
command -v depmod >/dev/null || err 'depmod missing.'

TMP="$(mktemp -d)"
log "Downloading only PR #220's audio header at pinned commit ${PR_HEAD:0:10}..."
curl --fail --location --silent --show-error --retry 2 --connect-timeout 12 --max-time 90 "$PR_FILE" -o "$TMP/cirrus_apple.h.new" || err 'Download failed; no files modified.'
[[ "$(git hash-object "$TMP/cirrus_apple.h.new")" == "$NEW_BLOB" ]] || err 'Downloaded source failed pinned Git blob verification. No changes made.'
log 'Source and download checks passed. Exact original header and PR #220 header confirmed.'
log "Running kernel: $KERNEL; module: $MODULE_FILE"

if [[ $MODE == --check ]]; then
  log 'CHECK COMPLETE: nothing was modified.'
  log 'Compilation and device behavior cannot be verified until --install is run.'
  exit 0
fi

[[ ! -e "$BACKUP/module.original" && ! -e "$BACKUP/cirrus_apple.h.original" ]] || err "Existing backup found at $BACKUP. No overwrite permitted; use --rollback or inspect backups."
mkdir -p "$BACKUP"
cp -a -- "$HEADER" "$BACKUP/cirrus_apple.h.original"
cp -a -- "$DKMS_CONF" "$BACKUP/dkms.conf.original"
cp -a -- "$MODULE_FILE" "$BACKUP/module.original"
printf '%s\n' "$MODULE_FILE" > "$BACKUP/module-path"
printf '%s\n' "$KERNEL" > "$BACKUP/kernel"
log "Backups saved at $BACKUP"

IN_TRANSACTION=1
log 'Replacing source header only (temporary until DKMS build succeeds).'
cp -a -- "$TMP/cirrus_apple.h.new" "$HEADER"
log 'Building CS8409 for installed Ubuntu kernel; original loaded driver remains in memory.'
dkms build -m "$DKMS_NAME" -v "$DKMS_VERSION" -k "$KERNEL" --force \
  2>&1 | tee "$BACKUP/build.log"
log 'Build succeeded. Installing built module for NEXT boot (no live module reload).'
dkms install -m "$DKMS_NAME" -v "$DKMS_VERSION" -k "$KERNEL" --force \
  2>&1 | tee "$BACKUP/install.log"
depmod -a "$KERNEL"
[[ "$(git hash-object "$HEADER")" == "$NEW_BLOB" ]] || err 'Source header changed unexpectedly during installation.'
[[ -f "$MODULE_FILE" ]] || err 'Expected installed CS8409 driver not found.'
printf '%s\n' "$(date -Is) kernel=$KERNEL pr=${PR_HEAD:0:10}" > "$BACKUP/installed"
IN_TRANSACTION=0
log 'SUCCESS: PR #220 installed on disk. Reboot manually and test audio after deep sleep.'
log "Rollback: sudo bash $(basename "$0") --rollback"
log "No Wi-Fi, NVMe, Touch Bar, sleep mode or kernel settings were changed."
