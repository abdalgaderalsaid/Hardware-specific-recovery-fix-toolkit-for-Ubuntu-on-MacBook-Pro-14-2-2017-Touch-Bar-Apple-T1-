# Technical notes — traceable observations and root-cause candidates

**Test case:** MacBookPro14,2 (A1706) Apple T1 `05ac:8600`, Ubuntu 26.04.1, kernel `7.0.0-38-generic`, Oct 23–24 2026.

## 1. BCM43602 cold association

Observed `brcmfmac` firmware initialization without successful association (`CTRL-EVENT-ASSOC-REJECT status_code=16`). Reproduced association success after a manual PCI remove/rescan of `0000:02:00.0`, without replacing `.bin.zst` firmware. The install timer checks for PCI IDs `14e4:43ba` and disconnected NetworkManager Wi-Fi first, then removes this PCI function, sleeps 2 seconds, and rescans. This intentionally leaves `01:00.0` NVMe alone. `OnBootSec=10s`, `AccuracySec=1s` was owner-selected.

NVRAM source is pinned to `nohzafk/omarchy-macbookpro-t1` commit `8e479f0...` and verified with Git object hash `bd7af7c6f01df3ccee1471d36cb8df15d618a6aa`, then personalized with the *local* permanent hardware MAC. Avoid distributing a modified NVRAM file.

## 2. Deep sleep and NVMe

S3 deep is selected (`/sys/power/mem_sleep: s2idle [deep]`), `NVMe 0000:01:00.0 d3cold_allowed=0` retained by `nvme-d3cold.service`. Core Wi-Fi and audio resumed successfully. `pm_async=1` was already set; there was no useful optimization from changing it. Kernel Thunderbolt warnings appeared at resume but their observed per-callback time was roughly 64 ms.

## 3. Apple T1 Touch Bar driver

The working DKMS modules are `apple-ib-drv/0.1`: `apple_ibridge` and `apple_touchbar`; `apple-ib-tb` is a different, legacy module name and is absent. Legacy `mbp-t1-touchbar-bind.service` failed with `modprobe: FATAL: Module apple-ib-tb not found` and must not be used here.

Physical HID USB interfaces:

```text
1-3:1.2 -> 0003:05AC:8600.0001 -> apple-ibridge-hid
1-3:1.3 -> 0003:05AC:8600.0003 -> apple-ibridge-hid
```

The virtual **mode** interface `0003:1D6B:0301.0002` was bound to `apple-touchbar`, while virtual **display** `0003:1D6B:0301.0005` was bound to `hid-sensor-hub`. `apple-touchbar`'s probe path accepts mode-only on T1, but the unpatched `.reset_resume` required **both** `mode_iface.hdev` and `disp_iface.hdev` to be present and un-suspended. Corrective local modifications were:

```c
.suspend = appletb_suspend,
.resume = appletb_reset_resume,
.reset_resume = appletb_reset_resume,
```

and changing the condition inside `appletb_reset_resume` to:

```c
if (tb_dev->mode_iface.hdev &&
    !tb_dev->mode_iface.suspended &&
    (tb_dev->is_t1 ||
     (tb_dev->disp_iface.hdev &&
      !tb_dev->disp_iface.suspended))) {
```

This produced `tb: Touchbar resumed` and initially enabled the bar after suspend. Later tests confirmed that **the software log alone was insufficient**: the actual panel stayed dark unless the T1 firmware-level wake call was performed. Repeating HID unbind/rebind caused `Duplicate connect` and `Failed to create sysfs attributes (-17)`; a clean reboot was required.

`skip_acpi_power=1` was retained throughout. Changing it to `0` at probe is particularly dangerous. USB runtime autosuspend rule was corrected from invalid `DEVTYPE==` to valid `ENV{DEVTYPE}=="usb_device"`.

## 4. T1 display wake and 5-second timing

The user manually ran and verified the following **risky** ACPI firmware method on the same MacBookPro14,2:

```text
\_SB.PCI0.XHC1.RHUB.ASOC.SOCW 0x1
```

It returned `0x0` and the Touch Bar lit. Initially the older service unexpectedly continued running because a `.backup` file with executable permission remained in `/usr/lib/systemd/system-sleep/`. Once legacy hooks were cleaned up, the bar remained dark despite successful driver resume. An attempted 1-second fast-wake service was never called (no journal entries), because its dispatch hook had not been active. The **final successful** configuration used an active `systemd-sleep` post hook with `systemctl --no-block start mbp-t1-fast-wake.service`, and a 5-second `ExecStartPre` sleep:

```text
08:21:09  hook scheduled recovery
08:21:14  ACPI sent; returned 0x0
08:21:15  Touch Bar display on; user confirmed working
```

**Subsequent input regression and resolution (2026-10-24):** The owner tested volume, brightness, and Fn keys after S3. The panel was lit by the five-second ACPI wake, but `evtest` showed repeated `KEY_UNKNOWN` (240) on the virtual iBridge input node. Reviewing the actual source identified a mismatched success convention in T1's one-byte `usb_control_msg()` path; see §5 below. After applying the standalone patch and rebooting, **the owner confirmed the controls work**. This is owner feedback for one hardware/kernel combination, not independent lab reproduction.

This **does not prove** 5 seconds is the minimum safe interval and does not guarantee reliability over every future suspend cycle. ACPI can hard-freeze other T1 systems. Consequently this packaged script requires an explicit `--enable-t1-wake --acknowledge-acpi-risk` invocation. No retry, no ACPI call from driver probe, and no change to `skip_acpi_power=1`.

## 5. T1 USB mode success code and `KEY_UNKNOWN` root cause

On this T1 device, `appletb_set_tb_mode()` sends a **single byte** by `usb_control_msg()` using `USB_TYPE_VENDOR | USB_RECIP_INTERFACE`. When the USB transfer succeeds it returns the **number of bytes sent** — `1` in this case. The delayed worker, however, checks `if (rc1 == 0)` before committing `tb_dev->cur_tb_mode = pending_mode`.

Before the correction, the transfer could succeed while `cur_tb_mode` remained `APPLETB_CMD_MODE_OFF` after S3. The input filter explicitly suppresses real key events (emitting `KEY_UNKNOWN` instead) when `cur_tb_mode == OFF` or `cur_tb_disp == OFF`. This was observed as repeated `KEY_UNKNOWN` reports from `/dev/input/event7` after S3 (the event number is not stable across reboots).

The tested **T1-only** correction, inserted **immediately after** the `usb_control_msg()` retry loop in `appletb_set_tb_mode()`:

```c
/* MBP14_2_T1_USB_RC_NORMALIZATION: USB returns bytes; worker expects 0. */
if (rc == 1)
    rc = 0;
else if (rc >= 0)
    rc = -EIO;
```

This normalizes exactly one successfully transferred byte to the worker's `0` success convention, flags unexpected nonnegative short transfers as errors, and leaves the T2 request path untouched. The main installer applies the fix together with the prior T1-only resume modifications, checks source structure, makes a source backup, and builds DKMS for the running kernel **only if the source changes**. Already patched source is preserved without reinstalling the current module.

The owner reports that the previously broken buttons now work after the dedicated correction. **Not yet demonstrated:** stable behavior over many suspend cycles, separate hardware/firmware revisions, fully automated new installation, or other Linux kernels. See [Troubleshooting](TROUBLESHOOTING.md#touch-bar-lit-but-buttons-send-key_unknown-after-s3) for verification.

## 6. CS8409 audio

Existing audio fix uses `davidjo/snd_hda_macbookpro` pinned to `cb27cc483f4fe98be03a4f4bef466c00aa7d244b`; PR #220 pinned header at `b8bc4d935335a9a5476c478d491adf9b18012f58` (`git hash-object` blob `116f62e8af7b9055357968b911dc75aa4286be4b`). The bundled `MBP14_2-CS8409-PR220.sh` provides narrow rollback. It is not a general solution for other CS8409 layouts or kernels.

## Attribution

The code in this repository is a *wrapper* and small, device-specific fixes informed by:

- https://github.com/vfontanela/macbookpro14-linux-support
- https://github.com/nohzafk/omarchy-macbookpro-t1
- https://github.com/AJ-dev-i60/t1-touchbar
- https://github.com/davidjo/snd_hda_macbookpro
- https://gist.github.com/roadrunner2/1289542a748d9a104e7baec6a92f9cd7

Nothing here includes Apple's EmbeddedOS images or personal device identifiers. All statements about the owner's machine come from their observed command output, not new reproduction by the authors of the repo package.
