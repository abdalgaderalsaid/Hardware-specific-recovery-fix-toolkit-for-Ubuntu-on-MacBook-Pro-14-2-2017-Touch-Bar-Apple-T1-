# Troubleshooting and rollback

## Read-only state snapshot

```bash
sudo bash ./MBP14_2-FIX-v5.sh --report
sudo journalctl -b -k --no-pager | grep -Ei 'PM: suspend|Touchbar (suspended|resumed)|brcmfmac|tb_cfg_(read|write)' | tail -60
```

Save a *sanitized* summary only. Before posting reports, remove MAC addresses, Wi-Fi SSIDs, any serial, Apple activation/nonce material, and private keys.

## Wi-Fi appears but cannot associate after a cold boot

Observed chip: BCM43602 `14e4:43ba`, module `brcmfmac`. Firmware loads but the access point may reject association until PCI re-enumeration. The helper installed in `/usr/local/sbin/mbp-bcm43602-recover` is run by `mbp-bcm43602-recover.timer` with **`OnBootSec=10s`, `AccuracySec=1s`**, conditional on Wi-Fi not connected. **Never** run PCI remove/rescan if Wi-Fi is working or if the PCI IDs/slot differ. Preserve calibration's local `macaddr`; do not copy anyone else's MAC.

```bash
systemctl list-timers --all | grep mbp-bcm43602
sudo journalctl -b -u mbp-bcm43602-recover.service --no-pager
nmcli device status
```

To disable future boot recovery, `sudo systemctl disable --now mbp-bcm43602-recover.timer`. Do not remove the NVMe PCI endpoint; it is on `01:00.0` not `02:00.0`.

## NVMe sleep failure / no deep S3

```bash
cat /sys/power/mem_sleep                  # expect s2idle [deep]
cat /sys/bus/pci/devices/0000:01:00.0/d3cold_allowed   # expect 0
systemctl status nvme-d3cold.service --no-pager
```

Never change `d3cold_allowed` for the Wi-Fi card in lieu of the NVMe endpoint. The installer preserves pre-existing `nvme-d3cold.service` and will not rewrite it.

## Touch Bar dark after S3

```bash
lsusb -d 05ac:8600
cat /sys/module/apple_ibridge/parameters/skip_acpi_power
sudo journalctl -b -k --no-pager | grep -Ei 'Touchbar suspended|Touchbar resumed|apple-touchbar.*Failed' | tail -30
sudo journalctl -b -u mbp-t1-fast-wake.service --no-pager -n 35
sudo journalctl -b -t mbp-t1-wake --no-pager -n 10
```

- `Touchbar resumed` is emitted **before** actual display response can be confirmed; this is not proof of a lit screen.
- A manually verified T1 firmware wake call solved a dark bar on one MacBookPro14,2. **It is dangerous**: using `ASOC.SOCW(1)` can hard-freeze some machines. Never add a loop/retry, never force `skip_acpi_power=0`, and never use it while work is unsaved.
- Old `90-mbp-t1-resume.backup` files **inside** `systemd-sleep` were erroneously executed after sleep. Move backups *outside* system hook directories. `--enable-t1-wake` disables the older known hooks.
- Legacy `mbp-t1-touchbar-bind.service` refers to missing `apple-ib-tb` and attempts disruptive USB re-probe; it does not fit the `apple-ib-drv` kernel 7 installation.
- HID unbind/rebind produced `Duplicate connect` and `Failed to create sysfs attributes (-17)`; **stop and reboot** rather than trying again.

**Disable the risky wake hook:**

```bash
sudo bash ./MBP14_2-FIX-v5.sh --disable-t1-wake
# or immediately:
sudo chmod -x /usr/lib/systemd/system-sleep/95-mbp-t1-wake
```

If the service is already running, stopping the hook does not cancel that invocation. Save data and wait for completion; do not force interrupts into firmware calls.

## Touch Bar lit but buttons send `KEY_UNKNOWN` after S3

**Previously reproduced on the owner's A1706:** After S3, the five-second ACPI `SOCW(1)` firmware wake restored illumination but not the volume, brightness or Fn functions. `sudo evtest` on the iBridge virtual input reported repeated **`KEY_UNKNOWN` (240)** instead of functional key codes. A reboot made all buttons work until the next S3 cycle.

**2026-10-24 update:** The owner confirmed controls started working after applying `MBP14_2-T1-USB-RETURN-FIX.sh` (which normalizes the 1-byte T1 `usb_control_msg()` success result to `0`) and rebooting. That fix is **now integrated into the main v5.2 script**, so do not apply the standalone script again when the marker is already present. Broad reproduction and long-term S3 reliability remain untested.

```bash
# Read-only source verification:
grep -n 'MBP14_2_T1_USB_RC_NORMALIZATION' /usr/src/apple-ib-drv-0.1/apple-touchbar.c
sudo bash ./MBP14_2-FIX-v5.sh --report
# After reboot and a controlled deep S3 test:
sudo apt install evtest
# Identify the correct event node using /proc/bus/input/devices or:
./tools/check-touchbar-input.sh
# Example only — event7 can change across boots:
sudo timeout 15s evtest /dev/input/event7
```

Normal functional events include `KEY_VOLUMEUP`, `KEY_VOLUMEDOWN`, `KEY_BRIGHTNESSUP`, `KEY_BRIGHTNESSDOWN`, `KEY_F1`–`KEY_F12`, rather than exclusively `KEY_UNKNOWN`. Do not type passwords during input capture. If the marker is present in source but keys fail, confirm that DKMS rebuilt and **the patched module was loaded after reboot**; do not blindly reapply a patch or reload a live HID interface.

For a machine without the patch, prefer the integrated installer after reviewing its code:

```bash
sudo bash ./MBP14_2-FIX-v5.sh --install --country XX
# reboot normally after successful DKMS build/install; test both cold boot and S3
```

The separate helper can be used for a narrowly scoped test/rollback:

```bash
sudo bash ./MBP14_2-T1-USB-RETURN-FIX.sh --check
sudo bash ./MBP14_2-T1-USB-RETURN-FIX.sh --apply
# after reboot, test input and suspend; to roll back only when the helper created its backup:
sudo bash ./MBP14_2-T1-USB-RETURN-FIX.sh --rollback
```

**Important:** A source-level fix alone does not light the display on this machine after S3; the user also needed the **separate opt-in firmware wake** described above. That firmware call retains its risk of hard freeze and is never enabled automatically by `--install`.

## Restore a T1 source change made by this script

```bash
sudo bash ./MBP14_2-FIX-v5.sh --restore-t1-source
# Manually reboot afterwards.
```

Only restores backed-up source files created by this revised script, then rebuilds DKMS for the running kernel. If the driver was originally patched **outside** this script, inspect and restore your own original backup in `/usr/src/apple-ib-drv-0.1/`. Do not overwrite unknown code.

## Audio CS8409

The bundled helper expects **kernel `7.0.0-38-generic`** and the original audio source pin `cb27cc4`. It validates upstream PR #220's header blob before modifying it. It will refuse a dirty or unfamiliar source. Never play a diagnostic tone to raw `hw:0,0` on this machine; use normal PulseAudio/PipeWire desktop output.

```bash
sudo bash ./MBP14_2-CS8409-PR220.sh --status
sudo bash ./MBP14_2-CS8409-PR220.sh --rollback  # if its own backup exists
```

## Restore backed-up config files

Each changed config is copied to `/var/backups/mbp14-2-v5.2/<timestamp>-<pid>/original/<absolute-path>`; missing-original markers are under `absent/`. **Backups are root-private**. Restore an individual file after review, e.g.:

```bash
sudo ls -ld /var/backups/mbp14-2-v5.2/*
# Example, replace <run> with the actual backup directory:
sudo cp -a /var/backups/mbp14-2-v5.2/<run>/original/etc/modprobe.d/10-wifi-regdom.conf /etc/modprobe.d/10-wifi-regdom.conf
```

No universal blind `--rollback-all`: some Wi-Fi firmware files contain private local MACs and a driver may have been upgraded by Ubuntu between runs. Restore changes selectively and reboot.

## Secure Boot / DKMS

```bash
mokutil --sb-state
modinfo -F signer apple_touchbar
dkms status
uname -r
```

A DKMS entry `installed (Differences between built and installed modules)` alone does not prove a broken driver, as compression/signing can change installed images. Compare `srcversion` of the loaded and installed module, test the real Touch Bar after S3, and inspect the DKMS build log if a module is actually missing.

## Thunderbolt warnings / resume slowness

`tb_cfg_read/write` warnings appeared in logs; a recorded `pci_pm_resume_noirq` call lasted about **64 ms**, so those warnings do not by themselves prove several seconds of delay. In the recorded test, the desktop woke quickly, and the missing display was Touch Bar only. Do not disable the entire USB-C/Thunderbolt controller as a cosmetic speed tweak.
