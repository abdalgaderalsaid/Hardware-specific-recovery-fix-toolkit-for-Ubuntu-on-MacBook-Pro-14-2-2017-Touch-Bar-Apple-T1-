# Publishing this project on GitHub

1. **Download/extract the project** and read the scripts before publishing. The package intentionally contains NO personalized Wi-Fi NVRAM file and no firmware blobs.
2. From inside the project directory run `python3 -m unittest discover -s tests -v` and `bash -n MBP14_2-FIX-v5.sh` to check packaging syntax; the tests cannot validate actual hardware behavior.
3. **Search for sensitive values** before committing, including serial number, `macaddr=`, local SSIDs, usernames, activation logs, MOK private keys or certificates. The .gitignore is only a safety net; don't rely on it to filter a manually added file.
4. Create an empty public GitHub repository named e.g. `macbookpro14-2-ubuntu-fixes`. Do NOT include a generated README/license remotely because this package already has those files.
5. From the extracted directory:

```bash
git init
git add MBP14_2-FIX-v5.sh MBP14_2-CS8409-PR220.sh MBP14_2-T1-USB-RETURN-FIX.sh README.md README.ar.md LICENSE .gitignore CHANGELOG.md docs/ legacy/ tests/
git diff --cached --check
git diff --cached --stat
git commit -m "Document Ubuntu 26.04.1 fixes for MacBookPro14,2"
git branch -M main
git remote add origin https://github.com/YOUR_USER/macbookpro14-2-ubuntu-fixes.git
git push -u origin main
```

Use your actual GitHub username/repository in `git remote add`. GitHub will require an authenticated workflow (credential manager, SSH key or token). Do not paste access tokens into your published files.

## Suggested issue template

When requesting help, supply **redacted** output from `--report`, kernel version, model, Wi-Fi PCI ID and exact user-visible failure. Include whether Wi-Fi, audio, NVMe and Touch Bar behave after a *cold boot* and after *S3 resume*. **Do not post device MAC, serial number, full logs with identifiers, secure-boot private keys, Apple firmware, recovery artifacts, or raw NVRAM.**

## Suggested release checklist

- Check previous version's original file remains under `legacy/`.
- Run static tests and `bash -n` on **all three** root-level shell scripts.
- Check the pinned audio and NVRAM upstream objects are still available and hashes match.
- If the T1 upstream `main` changes, review its installer, record its commit, and update the documentation before telling users to run `--allow-upstream-installers`.
- Require explicit acceptance of ACPI hard-lock risk and preserve `skip_acpi_power=1`.
- Record verified results separately for each model, distro and kernel. A success on `MacBookPro14,2/7.0.0-38` must not be described as tested on other models/kernels.
- Include how to disable T1 ACPI wake and Wi-Fi PCI recovery.

**Release disclaimer:** The scripts modify kernel drivers, systemd services and firmware configuration. Use with backups; no warranty.

## v5.2 status (October 24, 2026)

One owner reported successful recovery of brightness/volume/Fn after the Apple T1 USB return-code patch plus the separate firmware display wake. The integrated v5.2 installer is **synthetic-tested but has not been reinstalled end-to-end on fresh hardware**. Label the release experimental/beta until more devices and suspend cycles are verified. ACPI hard-lock warning must remain prominent.
