#!/usr/bin/env bash
# Safe, read-only Apple T1 virtual HID event diagnostic. No ACPI or USB resets.
set -Eeuo pipefail

usage() {
  cat <<'END'
Usage:
  ./tools/check-touchbar-input.sh --list
  sudo ./tools/check-touchbar-input.sh --monitor /dev/input/eventN

With --monitor, press only Touch Bar volume/brightness/Fn controls for 15 seconds.
Do not type passwords while monitoring. Event logs can reveal pressed keys.
Repeat AFTER S3 (lit but unresponsive) and AFTER A CLEAN BOOT; compare.
END
}

case "${1:---list}" in
  --list)
    echo '=== Input devices containing iBridge / Touch Bar (read-only) ==='
    if [[ -r /proc/bus/input/devices ]]; then
      awk 'BEGIN { RS=""; ORS="\n\n" } /iBridge|Touch ?Bar|touchbar/ { print }' /proc/bus/input/devices
    else
      echo 'Cannot read /proc/bus/input/devices' >&2; exit 1
    fi
    echo '=== Relevant /dev/input/eventN candidates ==='
    for f in /sys/class/input/event*/device/name; do
      [[ -r "$f" ]] || continue
      name="$(cat "$f")"
      if [[ "$name" =~ [iI][bB]ridge|[tT]ouch.?[bB]ar ]]; then
        event="${f%/device/name}"
        printf '%s : %s\n' "/dev/input/${event##*/}" "$name"
      fi
    done
    echo 'Use --monitor /dev/input/eventN to verify actual KEY events; --list alone does not establish input functionality.'
    ;;
  --monitor)
    [[ $# -eq 2 ]] || { usage >&2; exit 2; }
    dev="$2"
    [[ "$dev" =~ ^/dev/input/event[0-9]+$ ]] || { echo 'Expected /dev/input/eventN' >&2; exit 2; }
    [[ -c "$dev" ]] || { echo "Not a character device: $dev" >&2; exit 1; }
    [[ "$EUID" -eq 0 ]] || { echo 'Run --monitor with sudo.' >&2; exit 1; }
    command -v evtest >/dev/null 2>&1 || { echo 'evtest is missing: sudo apt install evtest' >&2; exit 1; }
    namefile="/sys/class/input/${dev##*/}/device/name"
    [[ -r "$namefile" ]] || { echo 'Input sysfs name is unavailable' >&2; exit 1; }
    name="$(cat "$namefile")"
    [[ "$name" =~ [iI][bB]ridge|[tT]ouch.?[bB]ar ]] || { echo "Refusing unrelated device: $name" >&2; exit 1; }
    echo "Testing $dev: $name"
    echo 'For the next 15 seconds press Touch Bar volume, brightness, Fn controls only.'
    echo 'Do not enter passwords. Compare this output after S3 vs cold boot.'
    set +e
    timeout --signal=INT --kill-after=2s 15s evtest "$dev"
    rc=$?
    set -e
    [[ $rc -eq 0 || $rc -eq 124 || $rc -eq 130 ]] || exit "$rc"
    echo '15-second event test finished.'
    ;;
  -h|--help) usage ;;
  *) usage >&2; exit 2 ;;
esac
