#!/usr/bin/env bash
# MBP14_2-FIX-v5.sh — maintained, rerunnable edition (v5.2, 2026-10-24)
# Tested configuration: MacBookPro14,2 A1706, Ubuntu 26.04.1, 7.0.0-38-generic.
# Based on the user's original MBP14_2-FIX-v5.sh. See docs/ and legacy/.
# CAUTION: Apple T1 ACPI SOCW(1) can HARD-FREEZE some machines. OPT-IN ONLY.
# T1 USB return-code normalization: owner confirmed restored brightness/volume/Fn after S3.
# Hardware-validated on ONE machine; downstream kernels/firmware may differ.
set -Eeuo pipefail
umask 077

VERSION='5.2-20261024'
ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
KVER="$(uname -r)"
MODEL="$(cat /sys/class/dmi/id/product_name 2>/dev/null || echo unknown)"
KTEST='7.0.0-38-generic'
SRC_DIR='/usr/local/src/mbp14-2'
AUDIO_SRC="$SRC_DIR/snd_hda_macbookpro"
TB_SRC='/usr/src/apple-ib-drv-0.1/apple-touchbar.c'
FW='/usr/lib/firmware/brcm'
BOARD="$FW/brcmfmac43602-pcie.Apple Inc.-MacBookPro14,2.txt"
GENERIC="$FW/brcmfmac43602-pcie.txt"
WIFI_SOURCE='https://raw.githubusercontent.com/nohzafk/omarchy-macbookpro-t1/8e479f0af82d16f47de811bef6e1a5cfd7d8c5f8/firmware/brcmfmac43602-pcie.txt'
WIFI_BLOB='bd7af7c6f01df3ccee1471d36cb8df15d618a6aa'
AUDIO_REPO='https://github.com/davidjo/snd_hda_macbookpro.git'
AUDIO_REV='cb27cc483f4fe98be03a4f4bef466c00aa7d244b'
AUDIO_FIXED_BLOB='116f62e8af7b9055357968b911dc75aa4286be4b'
AUDIO_ORIG_BLOB='7e9bcd1f6ff4e4ac76e3134c3440b7d9cf68bc0f'
TB_REPO='https://github.com/AJ-dev-i60/t1-touchbar.git'
MODE='--report'; EXPLICIT_MODE=0; COUNTRY=''; FORCE_NVRAM=0; ALLOW_INSTALLER=0; ACK_ACPI=0
STAMP="$(date +%Y%m%d-%H%M%S)-$$"
SAVE="/var/backups/mbp14-2-v5.2/$STAMP"
CHANGED=0

usage() { cat <<'EOF'
MacBookPro14,2 A1706 — Ubuntu 26.04.1 / kernel 7.0.0-38 (tested machine)

  sudo bash MBP14_2-FIX-v5.sh --report
  sudo bash MBP14_2-FIX-v5.sh --install --country AE
  sudo bash MBP14_2-FIX-v5.sh AE           # compatibility with original v5
  sudo bash MBP14_2-FIX-v5.sh --install --country AE --allow-upstream-installers
  sudo bash MBP14_2-FIX-v5.sh --enable-t1-wake --acknowledge-acpi-risk
  sudo bash MBP14_2-FIX-v5.sh --disable-t1-wake
  sudo bash MBP14_2-FIX-v5.sh --restore-t1-source

Default is read-only report. Re-running --install preserves existing Wi-Fi calibration,
working DKMS modules and custom configs unless a specific safe update is needed.
--allow-upstream-installers: on a clean machine ONLY, execute external T1/audio installers
  (review their upstream source first; not pinned for T1). Never on a working setup.
--enable-t1-wake: experimental, opt in to ONE risky T1 ACPI call after each suspend.
  After T1 USB rc correction, owner confirms brightness/volume/Fn work after S3 on one machine.
Do not use --force-nvram unless the original Wi-Fi calibration must be replaced.
No automatic reboot. Backup metadata saved under /var/backups/mbp14-2-v5.2/.
EOF
}
fail() { printf '[ERROR] %s\n' "$*" >&2; exit 1; }
log() { printf '\n[MBP %s] %s\n' "$VERSION" "$*"; }
warn() { printf '[WARN] %s\n' "$*" >&2; }
need() { command -v "$1" >/dev/null 2>&1 || fail "Missing executable: $1"; }
root_model() {
  (( EUID == 0 )) || fail 'Run with sudo.'
  [[ "$MODEL" == 'MacBookPro14,2' ]] || fail "Refusing to change '$MODEL'; supported ONLY on MacBookPro14,2."
}
save_file() {
  local path="$1" target="$SAVE/original$1"
  [[ -e "$path" || -L "$path" ]] || { mkdir -p "$SAVE/absent$(dirname "$path")"; : > "$SAVE/absent$path"; return; }
  [[ -e "$target" || -L "$target" ]] && return 0
  mkdir -p "$(dirname "$target")"
  cp -a -- "$path" "$target"
}
write_file() { # path mode; content supplied on standard input
  local path="$1" mode="$2" tmp
  tmp="$(mktemp)"; cat > "$tmp"
  if [[ -f "$path" ]] && cmp -s "$tmp" "$path"; then rm -f "$tmp"; return 0; fi
  save_file "$path"
  install -D -m "$mode" "$tmp" "$path"
  rm -f "$tmp"
  CHANGED=1
  log "Updated $path (backup $SAVE)"
}
read_sys() { [[ -r "$1" ]] && cat "$1" || printf unavailable; }
get_wifi_if() { iw dev 2>/dev/null | awk '$1=="Interface"{print $2; exit}'; }
mac_from_file() { [[ -f "$1" ]] && sed -nE 's/^macaddr=([[:xdigit:]:]{17}).*/\1/p' "$1" | head -n1 | tr A-F a-f || :; }
valid_mac() {
  local m="${1,,}" head
  [[ "$m" =~ ^([[:xdigit:]]{2}:){5}[[:xdigit:]]{2}$ ]] || return 1
  case "$m" in 00:90:4c:*|00:00:00:00:00:00|ff:ff:ff:ff:ff:ff) return 1;; esac
  head="${m%%:*}"; (( (16#$head & 1) == 0 ))
}

for arg in "$@"; do
  case "$arg" in
    --report|--install|--enable-t1-wake|--disable-t1-wake|--restore-t1-source)
      if (( EXPLICIT_MODE == 1 )) && [[ "$MODE" != "$arg" ]]; then
        fail 'Choose exactly one mode (install/report/enable/disable/restore).'
      fi
      MODE="$arg"; EXPLICIT_MODE=1;;
    --country=*) COUNTRY="${arg#*=}";;
    --country) : ;; # support --country AE via token below
    --allow-upstream-installers) ALLOW_INSTALLER=1;;
    --acknowledge-acpi-risk) ACK_ACPI=1;;
    --force-nvram) FORCE_NVRAM=1;;
    --help|-h) usage; exit 0;;
    [A-Za-z][A-Za-z]) COUNTRY="$arg";;
    *) fail "Unknown option: $arg";;
  esac
done
# Original v5's two-letter code also implies installation.
if (( EXPLICIT_MODE == 0 )) && [[ -n "$COUNTRY" ]]; then MODE='--install'; fi
COUNTRY="${COUNTRY^^}"

report() {
  log "Report: model=$MODEL kernel=$KVER"
  printf 'sleep: %s; async: %s\n' "$(read_sys /sys/power/mem_sleep)" "$(read_sys /sys/power/pm_async)"
  printf 'NVMe d3cold_allowed: %s\n' "$(read_sys /sys/bus/pci/devices/0000:01:00.0/d3cold_allowed)"
  printf 'T1 protection: %s\n' "$(read_sys /sys/module/apple_ibridge/parameters/skip_acpi_power)"
  printf 'T1 iBridge: '; lsusb -d 05ac:8600 2>/dev/null || true
  printf 'Wi-Fi interface: %s\n' "$(get_wifi_if || true)"
  printf 'Wi-Fi NVRAM board/generic: '; [[ -f "$BOARD" && -f "$GENERIC" ]] && echo present || echo incomplete
  printf 'Wi-Fi recovery timer: '; systemctl is-enabled mbp-bcm43602-recover.timer 2>/dev/null || true
  printf 'NVMe service: '; systemctl is-enabled nvme-d3cold.service 2>/dev/null || true
  printf 'Legacy T1 bind service: '; systemctl is-enabled mbp-t1-touchbar-bind.service 2>/dev/null || true
  printf 'Touch Bar ACPI wake hook: '; [[ -x /usr/lib/systemd/system-sleep/95-mbp-t1-wake ]] && echo enabled || echo disabled
  printf 'T1 S3 resume source patch: '; if [[ -f "$TB_SRC" ]] && grep -q 'tb_dev->is_t1 ||' "$TB_SRC"; then echo present-or-similar; else echo not-detected; fi
  printf 'T1 USB return-code source patch: '; if [[ -f "$TB_SRC" ]] && grep -Fq 'MBP14_2_T1_USB_RC_NORMALIZATION' "$TB_SRC"; then echo present; else echo not-detected; fi
  printf 'DKMS:\n'; dkms status 2>/dev/null | grep -E 'apple-ib-drv|snd_hda_macbookpro|mbp-t1-touchbar' || true
  printf 'Audio CS8409 module: '; modinfo -n snd_hda_codec_cs8409 2>/dev/null || true
  printf 'Apple Touch Bar module: '; modinfo -n apple_touchbar 2>/dev/null || true
  printf 'NOTE: module existence does not prove function after S3; test manually.\n'
}

base_packages() {
  local pkg audio_hash='' missing=()
  local packages=(git curl build-essential dkms "linux-headers-$KVER"
                  ethtool iw pciutils usbutils network-manager python3)
  if [[ "$KVER" == "$KTEST" ]]; then
    if [[ -f "$AUDIO_SRC/patch_cirrus/cirrus_apple.h" ]]; then
      audio_hash="$(git hash-object "$AUDIO_SRC/patch_cirrus/cirrus_apple.h" 2>/dev/null || true)"
    fi
    # Only pull kernel source if building/rebuilding audio is potentially required.
    [[ "$audio_hash" == "$AUDIO_FIXED_BLOB" ]] || packages+=(linux-source-7.0.0)
  fi
  for pkg in "${packages[@]}"; do
    dpkg-query -W -f='${Status}' "$pkg" 2>/dev/null | grep -Fq 'install ok installed' || missing+=("$pkg")
  done
  if (( ${#missing[@]} == 0 )); then
    log 'Dependencies already installed; skipping apt operations.'
    return 0
  fi
  log "Installing missing dependencies: ${missing[*]}"
  export DEBIAN_FRONTEND=noninteractive
  apt-get update
  apt-get install -y "${missing[@]}"
}

wifi_nvram() {
  local mac='' iface='' cand='' tmp hash
  [[ -d /sys/bus/pci/devices/0000:02:00.0 ]] || { warn 'Wi-Fi PCI path absent; leaving NVRAM unchanged'; return 0; }
  [[ "$(read_sys /sys/bus/pci/devices/0000:02:00.0/vendor)" == 0x14e4 && \
     "$(read_sys /sys/bus/pci/devices/0000:02:00.0/device)" == 0x43ba ]] || fail 'Unexpected Wi-Fi PCI ID; no NVRAM changes.'
  iface="$(get_wifi_if || true)"
  if [[ -n "$iface" ]]; then
    mac="$(ethtool -P "$iface" 2>/dev/null | awk '/[Pp]ermanent address/{print tolower($NF)}' || true)"
  fi
  if ! valid_mac "$mac"; then
    for cand in "$BOARD" "$GENERIC"; do
      mac="$(mac_from_file "$cand")"
      valid_mac "$mac" && break
    done
  fi
  valid_mac "$mac" || { warn 'Cannot verify a machine-specific permanent MAC. Refusing NVRAM installation.'; return 0; }
  if (( FORCE_NVRAM == 0 )); then
    # Never overwrite working board calibration. Restore a missing fallback by copying it.
    if [[ -f "$BOARD" && "$(mac_from_file "$BOARD")" == "$mac" ]]; then
      if [[ ! -f "$GENERIC" ]]; then
        save_file "$GENERIC"; install -D -m 0644 "$BOARD" "$GENERIC"; CHANGED=1
        log 'Copied existing board calibration to absent generic fallback.'
      elif [[ "$(mac_from_file "$GENERIC")" != "$mac" ]]; then
        warn 'Generic NVRAM MAC differs; preserving both files. Manual review required.'
      else
        log 'Keeping both existing Wi-Fi NVRAM calibration files.'
      fi
      return 0
    fi
    if [[ -f "$GENERIC" && "$(mac_from_file "$GENERIC")" == "$mac" ]]; then
      if [[ ! -f "$BOARD" ]]; then
        save_file "$BOARD"; install -D -m 0644 "$GENERIC" "$BOARD"; CHANGED=1
        log 'Copied existing generic calibration to absent board-specific filename.'
      else
        warn 'Board-specific NVRAM MAC differs; preserving both files. Manual review required.'
      fi
      return 0
    fi
    if [[ -f "$BOARD" || -f "$GENERIC" ]]; then
      warn 'Unverified existing NVRAM; refusing overwrite without --force-nvram.'
      return 0
    fi
  fi
  tmp="$(mktemp)"
  if ! curl --fail --location --silent --show-error --connect-timeout 15 --max-time 75 "$WIFI_SOURCE" -o "$tmp"; then
    rm -f "$tmp"; fail 'Pinned Broadcom NVRAM download failed.'
  fi
  hash="$(git hash-object "$tmp")"
  [[ "$hash" == "$WIFI_BLOB" ]] || { rm -f "$tmp"; fail "NVRAM verification failed ($hash)"; }
  sed -i -E "s/^macaddr=.*/macaddr=$mac/" "$tmp"
  [[ "$(grep -c '^macaddr=' "$tmp")" == 1 ]] || { rm -f "$tmp"; fail 'Invalid NVRAM macaddr entry.'; }
  save_file "$BOARD"; save_file "$GENERIC"
  install -D -m 0644 "$tmp" "$BOARD"
  install -D -m 0644 "$tmp" "$GENERIC"
  rm -f "$tmp"; CHANGED=1
  log 'Installed verified NVRAM with locally recovered hardware MAC (never publish it).'
}

wifi_config() {
  printf 'options cfg80211 ieee80211_regdom=%s\n' "$COUNTRY" | write_file /etc/modprobe.d/10-wifi-regdom.conf 0644
  cat <<'EOF' | write_file /etc/modprobe.d/99-mbp14-2-bcm43602.conf 0644
options brcmfmac roamoff=1 feature_disable=0x2000
EOF
  cat <<'EOF' | write_file /etc/NetworkManager/conf.d/10-mbp2017-wifi.conf 0644
[device]
wifi.scan-rand-mac-address=no
EOF
}

wifi_boot_recovery() {
  if [[ -f /usr/local/sbin/mbp-bcm43602-recover && \
        -f /etc/systemd/system/mbp-bcm43602-recover.service && \
        -f /etc/systemd/system/mbp-bcm43602-recover.timer ]]; then
    log 'Preserving existing Wi-Fi recovery implementation and its 10-second timer.'
    systemctl enable mbp-bcm43602-recover.timer
    return 0
  fi
  cat <<'EOF' | write_file /usr/local/sbin/mbp-bcm43602-recover 0755
#!/usr/bin/env bash
# MacBookPro14,2 BCM43602: PCI remove/rescan only if Wi-Fi is disconnected.
set -Eeuo pipefail
PCI='/sys/bus/pci/devices/0000:02:00.0'
[[ -e "$PCI/vendor" && -e "$PCI/device" ]] || exit 0
[[ "$(cat "$PCI/vendor")" == 0x14e4 && "$(cat "$PCI/device")" == 0x43ba ]] || exit 0
# Do not disrupt any connected Wi-Fi interface.
if command -v nmcli >/dev/null 2>&1 && nmcli -t -f TYPE,STATE device status 2>/dev/null | grep -Eq '^wifi:connected(:|$)'; then
  exit 0
fi
# The adapter already supports connections after PCI initialization; avoid root-port resets.
printf 1 > "$PCI/remove"
sleep 2
printf 1 > /sys/bus/pci/rescan
logger -t mbp-bcm43602 'Cold-boot PCI remove/rescan attempted (device was disconnected)'
EOF
  cat <<'EOF' | write_file /etc/systemd/system/mbp-bcm43602-recover.service 0644
[Unit]
Description=Recover BCM43602 Wi-Fi after cold boot (if disconnected)
ConditionPathExists=/sys/bus/pci/devices/0000:02:00.0
After=NetworkManager.service
[Service]
Type=oneshot
ExecStart=/usr/local/sbin/mbp-bcm43602-recover
EOF
  cat <<'EOF' | write_file /etc/systemd/system/mbp-bcm43602-recover.timer 0644
[Unit]
Description=One-shot BCM43602 PCI recovery 10s after boot
[Timer]
OnBootSec=10s
AccuracySec=1s
Unit=mbp-bcm43602-recover.service
[Install]
WantedBy=timers.target
EOF
  systemctl daemon-reload
  # enable for next boot only, NOT --now (no surprise live PCI removal).
  systemctl enable mbp-bcm43602-recover.timer
}

nvme_sleep() {
  [[ -f /sys/bus/pci/devices/0000:01:00.0/d3cold_allowed ]] || fail 'Expected NVMe PCI device missing; no sleep change.'
  if ! systemctl cat nvme-d3cold.service >/dev/null 2>&1; then
    cat <<'EOF' | write_file /etc/systemd/system/nvme-d3cold.service 0644
[Unit]
Description=Prevent Apple NVMe D3cold loss across deep sleep
ConditionPathExists=/sys/bus/pci/devices/0000:01:00.0/d3cold_allowed
Before=sleep.target
[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=/bin/sh -c 'echo 0 > /sys/bus/pci/devices/0000:01:00.0/d3cold_allowed'
[Install]
WantedBy=multi-user.target
EOF
  else
    log 'Preserving existing nvme-d3cold.service.'
  fi
  cat <<'EOF' | write_file /etc/systemd/sleep.conf.d/90-mbp14-2-deep.conf 0644
[Sleep]
MemorySleepMode=deep
EOF
  systemctl daemon-reload
  systemctl enable --now nvme-d3cold.service
  [[ "$(cat /sys/bus/pci/devices/0000:01:00.0/d3cold_allowed)" == 0 ]] || fail 'NVMe d3cold_allowed not set to 0.'
  [[ "$(cat /sys/power/mem_sleep)" == *'[deep]'* ]] || echo deep > /sys/power/mem_sleep
}

# Strict, T1-only patch. No live unbind/rebind and no ASOC.SOCW at probe.
touchbar_patch() {
  [[ -f "$TB_SRC" ]] || { warn "Missing $TB_SRC; Touch Bar patch not applied."; return 0; }
  if [[ ! -e /var/lib/dkms/apple-ib-drv/0.1/source ]]; then
    warn 'DKMS registration apple-ib-drv/0.1 missing; not rebuilding unrelated source.'; return 0
  fi
  [[ "$(readlink -f /var/lib/dkms/apple-ib-drv/0.1/source)" == "$(readlink -f /usr/src/apple-ib-drv-0.1)" ]] || fail 'Unexpected T1 DKMS source link.'
  local changed
  changed="$(python3 - "$TB_SRC" "$SAVE" <<'PY'
from pathlib import Path
import re
import sys
import shutil

p = Path(sys.argv[1])
backup = Path(sys.argv[2]) / 't1-source/apple-touchbar.c.before'
s = p.read_text()
s2 = s

# 1) Allow Apple's T1 mode-only HID interface to resume without a separate
# display HID interface. Retain the prior, known-working T2 requirements.
start = s2.find('static int appletb_reset_resume(')
end = s2.find('\n#endif', start)
if start < 0 or end < 0:
    raise SystemExit('Unexpected Touch Bar resume function; no modifications.')
part = s2[start:end]
old = ('if ((tb_dev->mode_iface.hdev && !tb_dev->mode_iface.suspended) &&\n'
       '\t    (tb_dev->disp_iface.hdev && !tb_dev->disp_iface.suspended)) {')
new = ('if (tb_dev->mode_iface.hdev &&\n'
       '\t    !tb_dev->mode_iface.suspended &&\n'
       '\t    (tb_dev->is_t1 ||\n'
       '\t     (tb_dev->disp_iface.hdev &&\n'
       '\t      !tb_dev->disp_iface.suspended))) {')
if new in part:
    pass
elif part.count(old) == 1:
    part = part.replace(old, new, 1)
else:
    raise SystemExit('Unknown resume interface guard; refusing blind patch.')
s2 = s2[:start] + part + s2[end:]

# 2) Register both Linux .resume and .reset_resume callbacks.
oldops = '\t.suspend = appletb_suspend,\n\t.reset_resume = appletb_reset_resume,'
newops = ('\t.suspend = appletb_suspend,\n'
          '\t.resume = appletb_reset_resume,\n'
          '\t.reset_resume = appletb_reset_resume,')
if newops not in s2:
    if s2.count(oldops) != 1:
        raise SystemExit('Unknown Touch Bar PM callback layout; no patch.')
    s2 = s2.replace(oldops, newops, 1)

# 3) FIX (2026-10-24): usb_control_msg returns *bytes transferred* on
# success. The 1-byte T1 command returns +1, while the worker accepts only
# rc1 == 0 as a successful mode-set (cur_tb_mode remains OFF otherwise).
# Normalize a complete T1 transfer to 0; never change the T2 path.
marker = 'MBP14_2_T1_USB_RC_NORMALIZATION'
start = s2.find('static int appletb_set_tb_mode(')
end = s2.find('static int appletb_set_tb_disp(', start + 1)
if start < 0 or end < 0:
    raise SystemExit('Unknown Touch Bar mode sender; no patch.')
modepart = s2[start:end]
if ('usb_control_msg(' not in modepart or 'if (rc != -EPIPE)' not in modepart or
        'if (rc1 == 0)' not in s2 or 'tb_dev->cur_tb_mode = pending_mode' not in s2):
    raise SystemExit('Unexpected T1 USB send/worker semantics; no patch.')
if marker not in modepart:
    m = list(re.finditer(r'(?m)^([ \t]*)\} while \(\+\+tries < 5\);[ \t]*$', modepart))
    if len(m) != 1:
        raise SystemExit('T1 retry-loop structure changed; no patch.')
    point = m[0]
    indent = point.group(1)
    injected = ('\n' + indent + '/* ' + marker + ': USB returns bytes; worker expects 0. */'
                + '\n' + indent + 'if (rc == 1)'
                + '\n' + indent + '\trc = 0;'
                + '\n' + indent + 'else if (rc >= 0)'
                + '\n' + indent + '\trc = -EIO;')
    modepart = modepart[:point.end()] + injected + modepart[point.end():]
    s2 = s2[:start] + modepart + s2[end:]
else:
    # A marker alone is insufficient proof that the right fix is present.
    if not re.search(r'if\s*\(rc\s*==\s*1\)\s*rc\s*=\s*0\s*;', modepart):
        raise SystemExit('T1 USB patch marker present with unexpected code.')

if s2 == s:
    print('unchanged')
else:
    backup.parent.mkdir(parents=True, exist_ok=True)
    if backup.exists():
        raise SystemExit('Source backup path already exists; refusing overwrite.')
    shutil.copy2(p, backup)
    p.write_text(s2)
    print('patched')
PY
)" || fail 'T1 patch failed; inspect source; no DKMS build attempted.'
  if [[ "$changed" == patched ]]; then
    log 'Building T1 DKMS for next reboot; original source backed up.'
    if ! dkms build -m apple-ib-drv -v 0.1 -k "$KVER" --force; then
      cp -a -- "$SAVE/t1-source/apple-touchbar.c.before" "$TB_SRC"
      fail 'T1 DKMS build failed; source restored. Inspect DKMS before reboot.'
    fi
    if ! dkms install -m apple-ib-drv -v 0.1 -k "$KVER" --force; then
      cp -a -- "$SAVE/t1-source/apple-touchbar.c.before" "$TB_SRC"
      fail 'T1 DKMS install failed; source restored. Review partial install before reboot.'
    fi
    depmod -a "$KVER"
    CHANGED=1
  else
    log 'T1 source already carries resume + USB return-code fixes; preserving installed module.'
  fi
}

touchbar_setup() {
  if ! dkms status -m apple-ib-drv -v 0.1 -k "$KVER" 2>/dev/null | grep -q 'installed'; then
    if (( ALLOW_INSTALLER == 0 )); then
      warn 'T1 DKMS not installed. Rerun with --allow-upstream-installers after reviewing upstream t1-touchbar/install.sh.'
      return 0
    fi
    log 'Installing T1 from upstream kernel-7-compatible fork (untrusted external script; explicit opt-in).'
    mkdir -p "$SRC_DIR"
    local dir="$SRC_DIR/t1-touchbar"
    if [[ ! -d "$dir/.git" ]]; then git clone "$TB_REPO" "$dir"; fi
    # Never reset an existing checkout automatically.
    [[ -f "$dir/install.sh" ]] || fail 'T1 upstream installer not found.'
    (cd "$dir" && bash ./install.sh --yes --no-service)
    log "T1 upstream source revision: $(git -C "$dir" rev-parse HEAD)"
  fi
  # Do not set skip_acpi_power=0 or probe ASOC.SOCW here.
  printf 'options apple_ibridge skip_acpi_power=1\n' | write_file /etc/modprobe.d/99-mbp-t1-safety.conf 0644
  cat <<'EOF' | write_file /etc/udev/rules.d/99-mbp-t1-power.rules 0644
# Correct udev syntax: DEVTYPE is an environment value, not a match key.
SUBSYSTEM=="usb", ENV{DEVTYPE}=="usb_device", ATTR{idVendor}=="05ac", ATTR{idProduct}=="8600", ATTR{power/control}="on", ATTR{power/autosuspend_delay_ms}="-1"
EOF
  udevadm control --reload
  # Legacy service references apple-ib-tb (not installed with apple-ib-drv).
  if systemctl cat mbp-t1-touchbar-bind.service >/dev/null 2>&1; then
    systemctl disable --now mbp-t1-touchbar-bind.service 2>/dev/null || true
    if [[ ! -e /etc/systemd/system/mbp-t1-touchbar-bind.service ]]; then
      systemctl mask mbp-t1-touchbar-bind.service || true
    fi
  fi
  touchbar_patch
}

audio_setup() {
  if [[ "$KVER" != "$KTEST" ]]; then
    warn "Audio PR #220 helper validated for $KTEST only; SKIPPING on $KVER."
    return 0
  fi
  local audio_helper="$ROOT_DIR/MBP14_2-CS8409-PR220.sh"
  [[ -f "$audio_helper" ]] || fail 'Audio helper is missing from the repository directory.'
  if [[ ! -f "$AUDIO_SRC/patch_cirrus/cirrus_apple.h" ]]; then
    if (( ALLOW_INSTALLER == 0 )); then
      warn 'Audio source missing. Rerun with --allow-upstream-installers after reviewing upstream audio installer.'
      return 0
    fi
    mkdir -p "$SRC_DIR"
    git clone "$AUDIO_REPO" "$AUDIO_SRC"
    git -C "$AUDIO_SRC" checkout --detach "$AUDIO_REV"
  fi
  local hash
  hash="$(git hash-object "$AUDIO_SRC/patch_cirrus/cirrus_apple.h")"
  if [[ "$hash" == "$AUDIO_FIXED_BLOB" ]]; then
    if dkms status -m snd_hda_macbookpro -v 0.1 -k "$KVER" 2>/dev/null | grep -q 'installed'; then
      log 'Audio PR #220 source and current-kernel DKMS already present; preserving working CS8409.'
    else
      warn 'Audio source is patched but current-kernel DKMS is not installed; manual rebuild required (not overwriting).'
    fi
    return 0
  fi
  if [[ "$hash" != "$AUDIO_ORIG_BLOB" ]]; then
    warn 'Audio source differs from both pinned versions; skipping to preserve custom driver.'
    return 0
  fi
  if ! dkms status -m snd_hda_macbookpro -v 0.1 -k "$KVER" 2>/dev/null | grep -q 'installed'; then
    if (( ALLOW_INSTALLER == 0 )); then
      warn 'Audio DKMS base not installed; --allow-upstream-installers required on a fresh install.'
      return 0
    fi
    [[ -f "$AUDIO_SRC/install.cirrus.driver.sh" ]] || fail 'Audio installer missing.'
    (cd "$AUDIO_SRC" && bash ./install.cirrus.driver.sh -i)
  fi
  bash "$audio_helper" --check
  bash "$audio_helper" --install
  CHANGED=1
}

cleanup_old_hooks() {
  local dir f base
  for dir in /etc/systemd/system-sleep /usr/lib/systemd/system-sleep; do
    [[ -d "$dir" ]] || continue
    for f in "$dir"/90-mbp-t1-resume "$dir"/90-mbp-t1-resume.backup \
             "$dir"/95-mbp-t1-fast-wake "$dir"/95-mbp-t1-wake; do
      [[ -e "$f" ]] || continue
      [[ "$f" == /usr/lib/systemd/system-sleep/95-mbp-t1-wake ]] && continue
      # Archive known legacy hooks outside the executable sleep-hook directories.
      base="$(echo "$f" | sed 's#/#_#g')"
      mkdir -p "$SAVE/retired-sleep-hooks"
      cp -a "$f" "$SAVE/retired-sleep-hooks/$base"
      chmod -x "$f"
    done
  done
  # Preserve original services; don't accidentally start these legacy paths.
  systemctl disable mbp-t1-wake-trigger.service 2>/dev/null || true
  systemctl disable mbp-t1-resume.service 2>/dev/null || true
}

t1_acpi_wake() {
  (( ACK_ACPI == 1 )) || fail 'Refusing dangerous ACPI wake without --acknowledge-acpi-risk.'
  [[ -f "$TB_SRC" ]] || fail 'T1 driver source missing.'
  [[ -e /sys/module/apple_ibridge/parameters/skip_acpi_power ]] || fail 'T1 driver is not loaded; reboot after driver install first.'
  [[ "$(cat /sys/module/apple_ibridge/parameters/skip_acpi_power)" == 1 ]] || fail 'T1 protection != 1; not proceeding.'
  command -v modinfo >/dev/null || fail 'modinfo missing.'
  modinfo acpi_call >/dev/null 2>&1 || fail 'acpi_call DKMS not available; install acpi-call-dkms first.'
  [[ "$(read_sys /sys/bus/usb/devices/1-3/idVendor)" == 05ac && \
     "$(read_sys /sys/bus/usb/devices/1-3/idProduct)" == 8600 ]] || fail 'Expected production T1 on USB 1-3 missing.'
  # Do not replace a verified working ACPI wake service on reruns.
  # The hardware-tested setup used mbp-t1-resume + mbp-t1-display.
  if [[ -x /usr/lib/systemd/system-sleep/95-mbp-t1-wake ]] &&
     systemctl cat mbp-t1-fast-wake.service >/dev/null 2>&1; then
    log 'Preserving already-enabled T1 ACPI wake hook and service.'
    return 0
  fi
  cleanup_old_hooks
  cat <<'EOF' | write_file /usr/local/sbin/mbp-t1-fast-wake 0755
#!/usr/bin/env bash
# Only after S3, only once. ASOC.SOCW(1) MAY HARD-FREEZE some Apple T1 Macs.
set -Eeuo pipefail
[[ "$(cat /sys/module/apple_ibridge/parameters/skip_acpi_power 2>/dev/null)" == 1 ]] || exit 0
T1='/sys/bus/usb/devices/1-3'
[[ "$(cat "$T1/idVendor" 2>/dev/null)" == 05ac && \
   "$(cat "$T1/idProduct" 2>/dev/null)" == 8600 ]] || exit 0
modprobe acpi_call
[[ -w /proc/acpi/call ]] || exit 1
printf '%s\n' '\_SB.PCI0.XHC1.RHUB.ASOC.SOCW 0x1' > /proc/acpi/call
result="$(cat /proc/acpi/call)"
printf 'ACPI result: %s\n' "$result"
[[ "$result" == 0x0 ]] || exit 1
# No HID unbind/rebind, no USB reset, no retry.
for t in /sys/bus/hid/devices/0003:1D6B:0301.*/idle_timeout; do
  [[ -w "$t" ]] || continue
  driver="$(basename "$(readlink -f "${t%/idle_timeout}/driver" 2>/dev/null || echo unknown)")"
  [[ "$driver" == apple-touchbar ]] && printf '%s\n' -1 > "$t"
done
logger -t mbp-t1-fast-wake 'T1 wake command completed once'
EOF
  cat <<'EOF' | write_file /etc/systemd/system/mbp-t1-fast-wake.service 0644
[Unit]
Description=Apple T1 Touch Bar recovery after deep S3 (opt-in risky ACPI)
[Service]
Type=oneshot
ExecStartPre=/usr/bin/sleep 5
ExecStart=/usr/local/sbin/mbp-t1-fast-wake
TimeoutStartSec=30
EOF
  cat <<'EOF' | write_file /usr/lib/systemd/system-sleep/95-mbp-t1-wake 0755
#!/bin/sh
# systemd-sleep hook: never call ACPI in the hook; dispatch asynchronously.
if [ "$1" = post ] && [ "$2" = suspend ]; then
    logger -t mbp-t1-wake 'Scheduling single T1 ACPI wake'
    /usr/bin/systemctl --no-block start mbp-t1-fast-wake.service
fi
exit 0
EOF
  systemctl daemon-reload
  warn 'ACPI still risks hard-freeze. Full button recovery additionally requires the T1 USB return-code driver fix and reboot.'
  log 'Enabled one ACPI SOCW call 5 seconds after suspend. Never run on unknown T1 models.'
}

disable_t1() {
  local f
  for f in /usr/lib/systemd/system-sleep/95-mbp-t1-wake \
           /etc/systemd/system-sleep/95-mbp-t1-fast-wake \
           /usr/lib/systemd/system-sleep/90-mbp-t1-resume \
           /usr/lib/systemd/system-sleep/90-mbp-t1-resume.backup; do
    [[ -e "$f" ]] && chmod -x "$f"
  done
  systemctl disable mbp-t1-wake-trigger.service 2>/dev/null || true
  log 'Disabled known automatic ACPI wake hooks; no reboot necessary.'
}

restore_t1_source() {
  local original
  original="$(find /var/backups/mbp14-2-v5.2 /var/backups/mbp14-2-v5.1 -type f -path '*/t1-source/apple-touchbar.c.before' 2>/dev/null | sort | tail -1)"
  [[ -n "$original" && -f "$original" ]] || fail 'No source backup created by this edition was found.'
  save_file "$TB_SRC"
  cp -a -- "$original" "$TB_SRC"
  dkms build -m apple-ib-drv -v 0.1 -k "$KVER" --force
  dkms install -m apple-ib-drv -v 0.1 -k "$KVER" --force
  log 'T1 source restored from backup; reboot before sleep testing.'
}

if [[ "$MODE" == --report ]]; then
  report
  exit 0
fi
root_model
need systemctl; need install; need bash
case "$MODE" in
  --disable-t1-wake) disable_t1; exit 0;;
  --restore-t1-source) need dkms; restore_t1_source; exit 0;;
  --enable-t1-wake) need modprobe; t1_acpi_wake; exit 0;;
  --install)
    [[ "$COUNTRY" =~ ^[A-Z]{2}$ ]] || fail 'Use --country AE (or another correct ISO 2-letter country code).'
    log 'BEGIN installation. Review script first; no automatic reboot.'
    base_packages
    wifi_nvram
    wifi_config
    wifi_boot_recovery
    nvme_sleep
    touchbar_setup
    audio_setup
    # Don't enable the dangerous ACPI path unless the operator explicitly opted in.
    if (( ACK_ACPI == 1 )); then
      warn 'For safety, ACPI wake must be enabled with a separate --enable-t1-wake command after reboot and verification.'
    fi
    if (( CHANGED == 1 )); then
      update-initramfs -u -k "$KVER"
    fi
    log 'Installation finished. Review warnings and reboot MANUALLY when convenient.'
    log "Report: sudo bash '$0' --report"
    log "Backups (if changes): $SAVE"
    ;;
  *) fail "Invalid mode: $MODE";;
esac
